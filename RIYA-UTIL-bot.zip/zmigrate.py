"""Auto-migrate SQLite tables: adds columns that the code expects but older DB files don't have. riya util team"""
import re
import glob
import sqlite3
from pathlib import Path


def _split_top(s):
    parts, depth, cur = [], 0, ""
    for ch in s:
        depth += (ch == "(") - (ch == ")")
        if ch == "," and depth == 0:
            parts.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    return parts


def parse_tables(root="."):
    tables = {}
    for f in glob.glob(f"{root}/**/*.py", recursive=True):
        txt = open(f, encoding="utf-8", errors="ignore").read()
        for m in re.finditer(r"CREATE TABLE IF NOT EXISTS\s+(\w+)\s*\(", txt, re.I):
            i, depth, j = m.end(), 1, m.end()
            while j < len(txt) and depth:
                depth += (txt[j] == "(") - (txt[j] == ")")
                j += 1
            cols = []
            for p in _split_top(txt[i:j - 1]):
                if p.upper().lstrip().startswith(("PRIMARY KEY", "UNIQUE", "FOREIGN", "CONSTRAINT", "CHECK")):
                    continue
                name = p.split()[0].strip('`"\'[]') if p.split() else ""
                if not re.fullmatch(r"\w+", name):
                    continue
                d = re.sub(r"(?i)\bPRIMARY KEY\b|\bAUTOINCREMENT\b|\bUNIQUE\b|\bNOT NULL\b", "", p).strip()
                d = re.sub(r"(?i)DEFAULT\s+FALSE", "DEFAULT 0", d)
                d = re.sub(r"(?i)DEFAULT\s+TRUE", "DEFAULT 1", d)
                cols.append((name, d))
            if len(cols) > len(tables.get(m.group(1), [])):
                tables[m.group(1)] = cols
    return tables


def run(data_dir, root="."):
    tables = parse_tables(root)
    added = []
    for dbf in Path(data_dir).glob("*.db"):
        try:
            con = sqlite3.connect(dbf)
            existing = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for t, cols in tables.items():
                if t not in existing:
                    continue
                have = {r[1] for r in con.execute(f"PRAGMA table_info({t})")}
                for name, d in cols:
                    if name not in have:
                        try:
                            con.execute(f"ALTER TABLE {t} ADD COLUMN {d}")
                            added.append(f"{dbf.name}:{t}.{name}")
                        except Exception:
                            pass
            con.commit()
            con.close()
        except Exception:
            pass
    return added
