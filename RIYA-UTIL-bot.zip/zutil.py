"""Shared helpers for RIYA UTIL cogs. riya util team"""
import os
import discord
from config import DATA_DIR, EMBED_COLOR, FOOTER
from emojis import CHECK, CROSS, INFO


def db_path(name: str) -> str:
    return str(DATA_DIR / name)


def embed(title: str = None, desc: str = None, color: int = EMBED_COLOR, footer: bool = True) -> discord.Embed:
    e = discord.Embed(title=title, description=desc, color=color)
    if footer:
        e.set_footer(text=FOOTER)
    return e


def ok(text: str) -> discord.Embed:
    return embed(None, f"{CHECK} {text}", 0x2ECC71)


def err(text: str) -> discord.Embed:
    return embed(None, f"{CROSS} {text}", 0xE74C3C)


def warn(text: str) -> discord.Embed:
    return embed(None, f"{INFO} {text}", 0xF1C40F)


def fmt_dur(seconds) -> str:
    try:
        seconds = int(seconds or 0)
    except Exception:
        return "LIVE"
    if seconds <= 0:
        return "LIVE"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def progress_bar(pos: int, total: int, size: int = 14) -> str:
    if not total:
        return "▬" * size
    i = min(size - 1, int(size * pos / total))
    return "▬" * i + "🔘" + "▬" * (size - i - 1)


def can_act(ctx, target: discord.Member) -> str | None:
    """Return an error string if ctx.author / bot can't act on target (role hierarchy)."""
    if target.id == ctx.author.id:
        return "You can't do that to yourself."
    if target.id == ctx.guild.owner_id:
        return "You can't do that to the server owner."
    if ctx.author.id != ctx.guild.owner_id and target.top_role >= ctx.author.top_role:
        return "That member's top role is higher or equal to yours."
    if target.top_role >= ctx.guild.me.top_role:
        return "That member's top role is higher or equal to mine."
    return None


def risky_above(guild: discord.Guild):
    """Roles (with real members) that sit above RIYA UTIL's top role and have dangerous perms -> RIYA UTIL could not punish them."""
    me = guild.me
    out = []
    for r in guild.roles:
        if r.is_default() or r.id == me.top_role.id or r.position < me.top_role.position:
            continue
        p = r.permissions
        if not (p.administrator or p.manage_guild or p.ban_members or p.kick_members or p.manage_roles or p.manage_channels):
            continue
        if any(m.id != guild.owner_id and m.id != me.id for m in r.members):
            out.append(r)
    return out


async def place_antinuke_roles(guild: discord.Guild):
    """Keep the antinuke roles directly UNDER the bot's highest role (RIYA UTIL+++ first, then RIYA UTIL)."""
    me = guild.me
    top = me.top_role.position
    moved = []
    for name, off in (("RIYA UTIL+++ ./unbypassble", 1), ("RIYA UTIL ./unbypassble", 2)):
        r = discord.utils.get(guild.roles, name=name)
        if r and r < me.top_role:
            pos = max(1, top - off)
            if r.position != pos:
                try:
                    await r.edit(position=pos, reason="RIYA UTIL: keep antinuke roles just under my highest role")
                    moved.append(name)
                except Exception:
                    pass
    return moved


DANGEROUS_PERMS = ("administrator", "manage_guild", "manage_roles", "manage_channels", "manage_webhooks", "manage_messages",
                   "manage_nicknames", "manage_events", "manage_threads", "manage_expressions", "ban_members", "kick_members",
                   "moderate_members", "mention_everyone", "view_audit_log", "view_guild_insights")


def role_perm_risk(role: discord.Role) -> list:
    return [p.replace("_", " ") for p in DANGEROUS_PERMS if getattr(role.permissions, p, False)]


def role_assign_error(guild: discord.Guild, actor, role: discord.Role, allow_dangerous: bool = False):
    """Why `actor` must NOT be able to hand out `role` through the bot (None = fine)."""
    if role.is_default():
        return "@everyone can't be used."
    if role.managed:
        return "That role is managed by an integration/bot."
    if role >= guild.me.top_role:
        return "That role is higher than (or equal to) **my** top role."
    if actor is not None and getattr(actor, "id", None) != guild.owner_id and role >= actor.top_role:
        return "That role is higher than (or equal to) **your** top role — you can't hand it out through me."
    if not allow_dangerous:
        risky = role_perm_risk(role)
        if risky:
            return "That role has dangerous permissions (**" + ", ".join(risky[:4]) + "**) so it can't be given automatically."
    return None
