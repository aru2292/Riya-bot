"""ZYRO security self-check. riya util team"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path


class GuardCheck(commands.Cog, name="Security"):
    """Checks whether ZYRO can really protect your server."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="zyrocheck", aliases=["antinukecheck", "securitycheck"], description="Check if ZYRO antinuke can really protect this server")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def zyrocheck(self, ctx):
        g, me = ctx.guild, ctx.guild.me
        async with aiosqlite.connect(db_path("anti.db")) as db:
            async with db.execute("SELECT status FROM antinuke WHERE guild_id=?", (g.id,)) as c:
                r = await c.fetchone()
        on = bool(r and r[0])
        p = me.guild_permissions
        above = [r for r in g.roles if not r.is_default() and r.position >= me.top_role.position and r.id != me.top_role.id
                 and (r.permissions.administrator or r.permissions.ban_members or r.permissions.manage_guild or r.permissions.manage_roles)]
        admin_bots = [m for m in g.members if m.bot and m.id != me.id and m.guild_permissions.administrator]
        try:
            import zpremium as zp
            prem = await zp.guild_premium(g.id)
            async with aiosqlite.connect(db_path("pantinuke.db")) as pdb:
                async with pdb.execute("SELECT enabled FROM pcfg WHERE guild_id=?", (g.id,)) as pc:
                    pr = await pc.fetchone()
            l2 = bool(prem and pr and pr[0])
        except Exception:
            prem, l2 = False, False
        r1 = discord.utils.get(g.roles, name="ZYRO ./unbypassble")
        placed = bool(r1 and r1.position == max(1, me.top_role.position - 2) or (r1 and r1.position >= me.top_role.position - 2))
        lines = [
            f"{'✅' if on else '❌'} Antinuke enabled",
            f"{'✅' if p.administrator else '❌'} I have Administrator",
            f"{'✅' if p.view_audit_log else '❌'} View Audit Log",
            f"{'✅' if not above else '❌'} My role is above every risky role" + (f" (**{len(above)}** above me: {', '.join(r.mention for r in above[:6])})" if above else ""),
            f"{'✅' if l2 else ('⚪' if not prem else '❌')} Layer 2 — ZYRO+++ Antinuke " + ('(premium, ON)' if l2 else ('(premium active, not enabled: `pantinuke enable`)' if prem else '(no premium)')),
            f"{'✅' if placed else '⚠️'} Antinuke role sits right under my top role" + ("" if placed or not r1 else " — run `antinukefix`"),
            f"{'✅' if not admin_bots else '⚠️'} Other bots with Administrator: **{len(admin_bots)}**" + (f" — {', '.join(b.mention for b in admin_bots[:6])}" if admin_bots else ""),
        ]
        if above:
            lines.append(f"\n**FIX:** Server Settings → Roles → drag **{me.top_role.name}** to the very TOP (under nothing). Without this ZYRO cannot ban/kick those admins.")
        good = on and p.administrator and p.view_audit_log and not above
        await ctx.send(embed=embed("🛡️ ZYRO Security Check", "\n".join(lines), 0x2ECC71 if good else 0xE74C3C))


async def setup(bot):
    await bot.add_cog(GuardCheck(bot))
