"""ZYRO antinuke extras: shared log channel + action logger, role placement, explanation. riya util team"""
import aiosqlite
import discord
from discord.ext import commands, tasks
from zutil import embed, ok, err, db_path, place_antinuke_roles
from cogs.anti_wl import is_trusted

DB = db_path("anti.db")


class AntinukePlus(commands.Cog, name="AntinukeTools"):
    """Log channel, role placement and an explanation of both antinuke layers."""

    def __init__(self, bot):
        self.bot = bot
        self.fixer.start()

    def cog_unload(self):
        self.fixer.cancel()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS zlog (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()

    async def log_channel(self, guild):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT channel_id FROM zlog WHERE guild_id=?", (guild.id,)) as c:
                r = await c.fetchone()
        return guild.get_channel(r[0]) if r else None

    @commands.command(name="antinukelogs", aliases=["anlogs", "anlog"])
    @commands.guild_only()
    async def antinukelogs(self, ctx, channel: discord.TextChannel = None):
        """antinukelogs #channel — every antinuke action (both layers) is logged there."""
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can do this."))
        async with aiosqlite.connect(DB) as db:
            if channel is None:
                await db.execute("DELETE FROM zlog WHERE guild_id=?", (ctx.guild.id,))
                await db.commit()
                return await ctx.send(embed=ok("Antinuke log channel removed."))
            await db.execute("INSERT OR REPLACE INTO zlog VALUES (?, ?)", (ctx.guild.id, channel.id))
            await db.commit()
        await ctx.send(embed=ok(f"Antinuke actions will be logged in {channel.mention}."))

    @commands.command(name="antinukefix", aliases=["anfix", "fixroles"])
    @commands.guild_only()
    async def antinukefix(self, ctx):
        """Moves the antinuke roles right under my highest role."""
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can do this."))
        moved = await place_antinuke_roles(ctx.guild)
        me = ctx.guild.me
        await ctx.send(embed=ok(f"Antinuke roles are now directly under **{me.top_role.name}**." if moved else
                                f"Antinuke roles are already directly under **{me.top_role.name}** (or don't exist yet)."))

    @commands.command(name="antinukeinfo", aliases=["aninfo", "layers"])
    async def antinukeinfo(self, ctx):
        """How the two antinuke layers work."""
        p = ctx.prefix
        e = embed("🛡️ How RIYA UTIL Antinuke works", color=0x7B2FFF)
        e.add_field(name="Layer 1 — Antinuke (free)", value=(
            f"`{p}antinuke enable` → role **ZYRO ./unbypassble**\n"
            "Anyone who is **not whitelisted** and bans, kicks, prunes, deletes/creates channels or roles, adds a bot, "
            "creates webhooks or pings @everyone is **punished instantly**.\n"
            f"`{p}whitelist @user` lets you pick exactly which actions a trusted person may do."), inline=False)
        e.add_field(name="Layer 2 — ZYRO+++ Antinuke (premium)", value=(
            f"`{p}pantinuke enable` → role **ZYRO+++ ./unbypassble**\n"
            "Even whitelisted people get **daily limits** (`" + p + "pwl @user`). If a trusted account is hacked or goes rogue, "
            "it can only do a few actions per day — beyond that it is **punished and the damage is reverted** "
            "(deleted channels/roles are re-created, bans undone, new bots kicked)."), inline=False)
        e.add_field(name="Role position", value=(
            "Discord only lets me punish people **below my highest role**. Put my role at the very **top** once — "
            "both antinuke roles are then placed **directly under it automatically** (`" + p + "antinukefix` to force)."), inline=False)
        e.add_field(name="Extras", value=f"`{p}antinukelogs #channel` • `{p}zyrocheck` • `{p}panic` • `{p}backup create`", inline=False)
        await ctx.send(embed=e)

    # ---- log what the free layer did (its bans/kicks carry "Unwhitelisted" in the audit reason) ----
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        if not self.bot.user or entry.user_id != self.bot.user.id:
            return
        reason = (entry.reason or "")
        if not any(k in reason.lower() for k in ("unwhitelisted", "antinuke", "zyro")):
            return
        ch = await self.log_channel(entry.guild)
        if not ch:
            return
        tid = getattr(entry.target, "id", None)
        who = f"<@{tid}> (`{tid}`)" if tid and entry.action in (discord.AuditLogAction.ban, discord.AuditLogAction.kick) else (getattr(entry.target, "name", None) or str(tid or "—"))
        e = embed("🛡️ ZYRO Antinuke action", f"**Action:** {entry.action.name.replace('_', ' ').title()}\n**Target:** {who}\n**Reason:** {reason[:200]}", 0xE74C3C)
        try:
            await ch.send(embed=e)
        except Exception:
            pass

    @tasks.loop(minutes=30)
    async def fixer(self):
        for g in self.bot.guilds:
            try:
                if g.me.guild_permissions.manage_roles:
                    await place_antinuke_roles(g)
            except Exception:
                pass

    @fixer.before_loop
    async def _w(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(AntinukePlus(bot))
