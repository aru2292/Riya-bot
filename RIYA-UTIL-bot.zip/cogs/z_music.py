"""ZYRO Music — premium player: control buttons, live progress, autoplay, 24/7, filters. riya util team"""
import os
import re
import time
import random
import asyncio
import logging
import shutil
import subprocess
from pathlib import Path
from collections import deque
from dataclasses import dataclass, field

import aiosqlite
import discord
from discord.ext import commands
from yt_dlp import YoutubeDL

from zutil import embed, ok, err, fmt_dur, progress_bar, db_path
from emojis import MUSIC, PLAY, PAUSE, STOP, SKIP, SHUFFLE, LOOP, VOLUME, INFINITY

log = logging.getLogger("zyro.music")
DB = db_path("music.db")
TMP = Path("/tmp/zyro_music")
TMP.mkdir(parents=True, exist_ok=True)

COOKIE_FILE = None
if os.getenv("YT_COOKIES"):
    COOKIE_FILE = "/tmp/yt_cookies.txt"
    with open(COOKIE_FILE, "w", encoding="utf-8") as _f:
        _f.write(os.getenv("YT_COOKIES"))

BASE_OPTS = {
    "format": "bestaudio[acodec=opus]/bestaudio/best",
    "quiet": True, "no_warnings": True, "noplaylist": True, "default_search": "ytsearch",
    "source_address": "0.0.0.0", "socket_timeout": 20, "retries": 5, "fragment_retries": 5,
}
if COOKIE_FILE:
    BASE_OPTS["cookiefile"] = COOKIE_FILE

FILTERS = {
    "off": "",
    "pro": "dynaudnorm=f=150:g=7:p=0.9,equalizer=f=60:t=q:w=1:g=3,equalizer=f=12000:t=q:w=1:g=2",
    "bass": "bass=g=12,dynaudnorm=f=200",
    "clear": "highpass=f=80,equalizer=f=3000:t=q:w=1:g=3,dynaudnorm=f=150:g=7",
    "loud": "dynaudnorm=f=100:g=5,volume=1.5,alimiter=limit=0.95",
    "treble": "treble=g=8",
    "nightcore": "asetrate=48000*1.25,aresample=48000",
    "slowed": "asetrate=48000*0.85,aresample=48000",
    "8d": "apulsator=hz=0.125",
    "vaporwave": "asetrate=48000*0.8,aresample=48000,aecho=0.8:0.9:40:0.3",
}
URL_RE = re.compile(r"https?://")


def ensure_opus() -> bool:
    if discord.opus.is_loaded():
        return True
    for n in ("libopus.so.0", "libopus.so", "opus", "/usr/lib/x86_64-linux-gnu/libopus.so.0", "/usr/lib/aarch64-linux-gnu/libopus.so.0"):
        try:
            discord.opus.load_opus(n)
        except Exception:
            continue
        if discord.opus.is_loaded():
            return True
    return False


@dataclass
class Track:
    title: str
    url: str
    duration: int = 0
    thumb: str = None
    requester: int = 0
    vid: str = None
    live: bool = False


@dataclass
class GuildPlayer:
    queue: deque = field(default_factory=deque)
    current: Track = None
    loop: str = "off"
    volume: float = 0.7
    filter: str = "pro"
    text: discord.abc.Messageable = None
    idle_task: asyncio.Task = None
    tick_task: asyncio.Task = None
    np_msg: discord.Message = None
    started_at: float = 0.0
    paused_at: float = 0.0
    twentyfour7: bool = False
    autoplay: bool = False
    skipped: bool = False
    cur_file: str = None
    history: deque = field(default_factory=lambda: deque(maxlen=30))


def _extract(query: str, flat: bool = False):
    opts = dict(BASE_OPTS)
    if flat:
        opts.update({"noplaylist": False, "extract_flat": "in_playlist"})
    with YoutubeDL(opts) as y:
        return y.extract_info(query, download=False)


def _download(url: str):
    opts = dict(BASE_OPTS)
    opts.update({"outtmpl": str(TMP / "%(id)s.%(ext)s"), "noplaylist": True})
    with YoutubeDL(opts) as y:
        info = y.extract_info(url, download=True)
        if "entries" in info:
            info = info["entries"][0]
        return info, y.prepare_filename(info)


def _to_track(info: dict, requester: int) -> Track:
    return Track(info.get("title", "Unknown"), info.get("webpage_url") or info.get("url"), info.get("duration") or 0,
                 info.get("thumbnail"), requester, info.get("id"), bool(info.get("is_live")))


def _related_sync(track: Track, history):
    try:
        vid = track.vid
        if vid and ("youtube.com" in (track.url or "") or "youtu.be" in (track.url or "")):
            info = _extract(f"https://www.youtube.com/watch?v={vid}&list=RD{vid}", True)
        else:
            info = _extract(f"ytsearch8:{track.title}", True)
        ents = [e for e in (info.get("entries") or []) if e and e.get("id") and e["id"] not in history and e["id"] != vid]
        if not ents:
            return None
        e = random.choice(ents[:10])
        return Track(e.get("title", "Unknown"), e.get("url") or e.get("webpage_url") or f"https://www.youtube.com/watch?v={e['id']}",
                     e.get("duration") or 0, None, 0, e["id"])
    except Exception as ex:
        log.warning("autoplay lookup failed: %s", str(ex)[:120])
        return None


# ---------------- player buttons ----------------
class PlayerView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    async def interaction_check(self, i: discord.Interaction) -> bool:
        vc = i.guild.voice_client if i.guild else None
        if not vc or not i.user.voice or i.user.voice.channel != vc.channel:
            await i.response.send_message("💜 Join **my voice channel** to use the player.", ephemeral=True)
            return False
        return True

    def _p(self, i):
        return self.cog.player(i.guild.id)

    async def _refresh(self, i):
        p = self._p(i)
        if p.current:
            await i.response.edit_message(embed=self.cog.np_embed(i.guild, p.current), view=self)
        else:
            await i.response.edit_message(view=None)

    @discord.ui.button(emoji=PAUSE, style=discord.ButtonStyle.primary, custom_id="zm_pause", row=0)
    async def pause_btn(self, i, b):
        vc, p = i.guild.voice_client, self._p(i)
        if vc.is_playing():
            vc.pause()
            p.paused_at = time.monotonic()
        elif vc.is_paused():
            vc.resume()
            p.started_at += time.monotonic() - p.paused_at
            p.paused_at = 0.0
        await self._refresh(i)

    @discord.ui.button(emoji=SKIP, style=discord.ButtonStyle.secondary, custom_id="zm_skip", row=0)
    async def skip_btn(self, i, b):
        vc, p = i.guild.voice_client, self._p(i)
        p.skipped = True
        if p.loop == "track":
            p.loop = "off"
        vc.stop()
        await i.response.send_message(f"{SKIP} Skipped by {i.user.mention}", ephemeral=True)

    @discord.ui.button(emoji=STOP, style=discord.ButtonStyle.danger, custom_id="zm_stop", row=0)
    async def stop_btn(self, i, b):
        vc, p = i.guild.voice_client, self._p(i)
        p.queue.clear()
        p.loop, p.skipped = "off", True
        vc.stop()
        await i.response.edit_message(view=None)

    @discord.ui.button(emoji=LOOP, style=discord.ButtonStyle.secondary, custom_id="zm_loop", row=0)
    async def loop_btn(self, i, b):
        p = self._p(i)
        order = ["off", "track", "queue"]
        p.loop = order[(order.index(p.loop) + 1) % 3]
        await self._refresh(i)

    @discord.ui.button(emoji=SHUFFLE, style=discord.ButtonStyle.secondary, custom_id="zm_shuffle", row=0)
    async def shuffle_btn(self, i, b):
        p = self._p(i)
        items = list(p.queue)
        random.shuffle(items)
        p.queue = deque(items)
        await i.response.send_message(f"{SHUFFLE} Queue shuffled.", ephemeral=True)

    @discord.ui.button(label="−10%", style=discord.ButtonStyle.secondary, custom_id="zm_vdown", row=1)
    async def vdown(self, i, b):
        await self._vol(i, -0.1)

    @discord.ui.button(label="+10%", style=discord.ButtonStyle.secondary, custom_id="zm_vup", row=1)
    async def vup(self, i, b):
        await self._vol(i, 0.1)

    async def _vol(self, i, d):
        p, vc = self._p(i), i.guild.voice_client
        p.volume = max(0.1, min(1.5, round(p.volume + d, 2)))
        if vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = p.volume
        await self._refresh(i)

    @discord.ui.button(emoji="📜", label="Queue", style=discord.ButtonStyle.secondary, custom_id="zm_queue", row=1)
    async def queue_btn(self, i, b):
        await i.response.send_message(embed=self.cog.queue_embed(i.guild, 1), ephemeral=True)

    @discord.ui.button(emoji=INFINITY, label="Autoplay", style=discord.ButtonStyle.secondary, custom_id="zm_auto", row=1)
    async def auto_btn(self, i, b):
        p = self._p(i)
        p.autoplay = not p.autoplay
        await self._refresh(i)


class Music(commands.Cog, name="Music"):
    """Premium music player: buttons, autoplay, 24/7, filters and a request channel."""

    def __init__(self, bot):
        self.bot = bot
        self.players: dict[int, GuildPlayer] = {}
        self.setup_channels: dict[int, int] = {}
        self.view = PlayerView(self)

    async def cog_load(self):
        print(f"[music] opus loaded: {ensure_opus()} | ffmpeg: {shutil.which('ffmpeg')}")
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS music_setup (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS vc247 (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()
            async with db.execute("SELECT guild_id, channel_id FROM music_setup") as cur:
                for g, c in await cur.fetchall():
                    self.setup_channels[g] = c
        for f in TMP.glob("*"):                      # clean old downloaded files
            try:
                if time.time() - f.stat().st_mtime > 7200:
                    f.unlink()
            except Exception:
                pass

    def player(self, gid: int) -> GuildPlayer:
        return self.players.setdefault(gid, GuildPlayer())

    # ---------- helpers ----------
    async def ensure_voice(self, ctx):
        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send(embed=err("Join a voice channel first."))
            return None
        vc, ch = ctx.voice_client, ctx.author.voice.channel
        try:
            if vc is None:
                vc = await ch.connect(self_deaf=True)
            elif vc.channel.id != ch.id:
                await vc.move_to(ch)
        except Exception as e:
            await ctx.send(embed=err(f"Can't join that channel: `{e}`"))
            return None
        return vc

    async def resolve(self, query: str, requester: int):
        loop = asyncio.get_running_loop()
        is_url = bool(URL_RE.match(query))
        is_playlist = is_url and ("list=" in query or "/sets/" in query or "playlist" in query)
        try:
            if is_playlist:
                info = await loop.run_in_executor(None, lambda: _extract(query, True))
                out = []
                for e in (info.get("entries") or [])[:100]:
                    if e:
                        out.append(Track(e.get("title", "Unknown"), e.get("url") or e.get("webpage_url"), e.get("duration") or 0, None, requester, e.get("id")))
                return out
            info = await loop.run_in_executor(None, lambda: _extract(query if is_url else f"ytsearch1:{query}"))
            if "entries" in info:
                info = (info["entries"] or [None])[0]
            if info:
                return [_to_track(info, requester)]
        except Exception as e:
            log.warning("primary extract failed (%s) -> SoundCloud", str(e)[:120])
        if not is_url:
            try:
                info = await loop.run_in_executor(None, lambda: _extract(f"scsearch1:{query}"))
                if "entries" in info:
                    info = (info["entries"] or [None])[0]
                if info:
                    return [_to_track(info, requester)]
            except Exception as e:
                log.warning("soundcloud fallback failed: %s", str(e)[:120])
        return []

    def _source(self, p: GuildPlayer, path, stream):
        af = FILTERS.get(p.filter, "")
        opts = "-vn" + (f' -af "{af}"' if af else "")
        if path:
            src = discord.FFmpegPCMAudio(path, options=opts, stderr=subprocess.PIPE)
        else:
            before = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin"
            src = discord.FFmpegPCMAudio(stream, before_options=before, options=opts, stderr=subprocess.PIPE)
        return discord.PCMVolumeTransformer(src, volume=p.volume)

    def now_pos(self, p: GuildPlayer) -> int:
        ref = p.paused_at or time.monotonic()
        return max(0, int(ref - p.started_at))

    def np_embed(self, guild, track: Track) -> discord.Embed:
        p, vc = self.player(guild.id), guild.voice_client
        paused = bool(vc and vc.is_paused())
        e = discord.Embed(color=0x7B2FFF, title=f"{MUSIC} Now Playing" + ("  ⏸" if paused else ""), description=f"### [{track.title[:90]}]({track.url})")
        if track.live:
            bar = "🔴 **LIVE**"
        else:
            pos = min(self.now_pos(p), track.duration or 0)
            bar = f"`{fmt_dur(pos)}` {progress_bar(pos, track.duration)} `{fmt_dur(track.duration)}`"
        e.add_field(name="Progress", value=bar, inline=False)
        e.add_field(name="Requested by", value=f"<@{track.requester}>" if track.requester else "✨ Autoplay")
        e.add_field(name="Volume", value=f"`{int(p.volume * 100)}%`")
        e.add_field(name="Loop", value=f"`{p.loop.title()}`")
        e.add_field(name="Filter", value=f"`{p.filter.title()}`")
        e.add_field(name="Autoplay", value="`On`" if p.autoplay else "`Off`")
        e.add_field(name="Up next", value=f"`{len(p.queue)}` song(s)")
        if track.thumb:
            e.set_image(url=track.thumb)
        e.set_footer(text="riya util team" + ("  •  24/7" if p.twentyfour7 else ""))
        return e

    def queue_embed(self, guild, page: int = 1) -> discord.Embed:
        p = self.player(guild.id)
        items = list(p.queue)
        per = 10
        pages = max(1, (len(items) + per - 1) // per)
        page = max(1, min(page, pages))
        lines = [f"`{i}.` [{t.title[:55]}]({t.url}) • `{fmt_dur(t.duration)}`"
                 for i, t in enumerate(items[(page - 1) * per: page * per], start=(page - 1) * per + 1)]
        now = f"**Now:** [{p.current.title[:60]}]({p.current.url})\n\n" if p.current else ""
        e = embed(f"{MUSIC} Queue — {len(items)} track(s)", now + ("\n".join(lines) or "*Nothing up next*"))
        e.set_footer(text=f"Page {page}/{pages} • Loop: {p.loop} • Filter: {p.filter} • riya util team")
        return e

    async def _finish_np(self, p: GuildPlayer):
        if p.tick_task:
            p.tick_task.cancel()
            p.tick_task = None
        if p.np_msg:
            try:
                await p.np_msg.edit(view=None)
            except Exception:
                pass
            p.np_msg = None

    async def _tick(self, guild, track):
        p = self.player(guild.id)
        try:
            while p.current is track and guild.voice_client:
                await asyncio.sleep(15)
                vc = guild.voice_client
                if p.current is not track or not p.np_msg:
                    break
                if vc and vc.is_playing():
                    try:
                        await p.np_msg.edit(embed=self.np_embed(guild, track))
                    except Exception:
                        break
        except asyncio.CancelledError:
            pass

    async def play_next(self, guild: discord.Guild):
        p, vc = self.player(guild.id), guild.voice_client
        if not vc or not vc.is_connected():
            return
        if p.idle_task:
            p.idle_task.cancel()
            p.idle_task = None
        await self._finish_np(p)
        loop = asyncio.get_running_loop()

        if p.loop == "track" and p.current:
            track = p.current
        else:
            if p.loop == "queue" and p.current:
                p.queue.append(p.current)
            if not p.queue and p.autoplay and p.current:
                rel = await loop.run_in_executor(None, lambda: _related_sync(p.current, set(p.history)))
                if rel:
                    p.queue.append(rel)
            if not p.queue:
                p.current = None
                if not p.twentyfour7:
                    p.idle_task = asyncio.create_task(self._idle_leave(guild))
                return
            track = p.queue.popleft()

        path = stream = None
        try:
            info = await loop.run_in_executor(None, lambda: _extract(track.url))
            if "entries" in info:
                info = info["entries"][0]
            track.title = info.get("title", track.title)
            track.duration = info.get("duration") or track.duration
            track.thumb = info.get("thumbnail") or track.thumb
            track.vid = info.get("id") or track.vid
            track.live = bool(info.get("is_live"))
            if track.live:
                stream = info.get("url")
            else:
                try:                       # download first: much more reliable than streaming from a datacenter IP
                    _, path = await loop.run_in_executor(None, lambda: _download(track.url))
                except Exception as e:
                    log.warning("download failed (%s) -> streaming", str(e)[:120])
                    stream = info.get("url")
            source = self._source(p, path, stream)
        except Exception as e:
            log.warning("play failed: %s", str(e)[:200])
            if p.text:
                await p.text.send(embed=err(f"Couldn't play **{track.title[:60]}** — skipping.\n`{str(e)[:150]}`"), delete_after=20)
            p.current = None
            return await self.play_next(guild)

        if p.cur_file and p.cur_file != path:
            try:
                os.remove(p.cur_file)
            except Exception:
                pass
        p.cur_file = path
        p.current, p.skipped = track, False
        p.started_at, p.paused_at = time.monotonic(), 0.0
        if track.vid:
            p.history.append(track.vid)
        began = time.monotonic()

        def after(error):
            elapsed = time.monotonic() - began
            if error:
                log.warning("player error: %s", error)
            if p.text and not p.skipped and elapsed < 4 and (track.duration or 0) > 20:
                detail = ""
                try:
                    proc = getattr(source.original, "_process", None)
                    if proc and proc.stderr:
                        detail = proc.stderr.read()[-350:].decode(errors="ignore")
                except Exception:
                    pass
                asyncio.run_coroutine_threadsafe(
                    p.text.send(embed=err(f"Playback stopped after {elapsed:.1f}s — ffmpeg/opus problem.\n```{detail or 'no ffmpeg output'}```Run `voicecheck` for details.")),
                    self.bot.loop)
            try:
                asyncio.run_coroutine_threadsafe(self.play_next(guild), self.bot.loop).result()
            except Exception:
                pass

        ensure_opus()
        kb = min(256, max(64, vc.channel.bitrate // 1000))
        try:
            vc.play(source, after=after, application="audio", bitrate=kb, signal_type="music", bandwidth="full")
        except TypeError:
            vc.play(source, after=after)
        if p.text:
            try:
                p.np_msg = await p.text.send(embed=self.np_embed(guild, track), view=self.view)
                p.tick_task = asyncio.create_task(self._tick(guild, track))
            except Exception:
                pass

    async def _idle_leave(self, guild):
        try:
            await asyncio.sleep(180)
            vc = guild.voice_client
            if vc and not vc.is_playing():
                await vc.disconnect()
        except asyncio.CancelledError:
            pass

    async def _play(self, ctx, query: str):
        vc = await self.ensure_voice(ctx)
        if not vc:
            return
        p = self.player(ctx.guild.id)
        p.text = ctx.channel
        async with ctx.typing():
            tracks = await self.resolve(query, ctx.author.id)
        if not tracks:
            return await ctx.send(embed=err("No results (YouTube may be blocking this server — see README: YT_COOKIES)."))
        for t in tracks:
            p.queue.append(t)
        busy = vc.is_playing() or vc.is_paused()
        if len(tracks) > 1:
            await ctx.send(embed=ok(f"Queued **{len(tracks)}** tracks from the playlist."))
        elif busy:
            e = embed(f"{MUSIC} Added to queue", f"**[{tracks[0].title[:80]}]({tracks[0].url})**\nPosition: `{len(p.queue)}` • Length: `{fmt_dur(tracks[0].duration)}`")
            if tracks[0].thumb:
                e.set_thumbnail(url=tracks[0].thumb)
            await ctx.send(embed=e)
        if not busy:
            await self.play_next(ctx.guild)

    # ---------- commands ----------
    @commands.hybrid_command(name="play", aliases=["p"], description="Play a song or add it to the queue")
    @commands.guild_only()
    async def play(self, ctx, *, query: str):
        await self._play(ctx, query)

    @commands.hybrid_command(name="join", aliases=["connect", "summon"], description="Make ZYRO join your voice channel")
    @commands.guild_only()
    async def join(self, ctx):
        vc = await self.ensure_voice(ctx)
        if vc:
            await ctx.send(embed=ok(f"Joined **{vc.channel.name}**"))

    @commands.hybrid_command(name="leave", aliases=["dc", "disconnect"], description="Disconnect and clear the queue")
    @commands.guild_only()
    async def leave(self, ctx):
        if not ctx.voice_client:
            return await ctx.send(embed=err("I'm not in a voice channel."))
        p = self.players.pop(ctx.guild.id, None)
        if p:
            await self._finish_np(p)
        await ctx.voice_client.disconnect()
        await ctx.send(embed=ok("Disconnected."))

    @commands.hybrid_command(name="pause", description="Pause the music")
    @commands.guild_only()
    async def pause(self, ctx):
        vc, p = ctx.voice_client, self.player(ctx.guild.id)
        if vc and vc.is_playing():
            vc.pause()
            p.paused_at = time.monotonic()
            return await ctx.send(embed=ok(f"{PAUSE} Paused."))
        await ctx.send(embed=err("Nothing is playing."))

    @commands.hybrid_command(name="resume", aliases=["unpause"], description="Resume the music")
    @commands.guild_only()
    async def resume(self, ctx):
        vc, p = ctx.voice_client, self.player(ctx.guild.id)
        if vc and vc.is_paused():
            vc.resume()
            p.started_at += time.monotonic() - p.paused_at
            p.paused_at = 0.0
            return await ctx.send(embed=ok(f"{PLAY} Resumed."))
        await ctx.send(embed=err("Nothing is paused."))

    @commands.hybrid_command(name="skip", aliases=["s", "next"], description="Skip the current song")
    @commands.guild_only()
    async def skip(self, ctx):
        vc = ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            p = self.player(ctx.guild.id)
            p.skipped = True
            if p.loop == "track":
                p.loop = "off"
            vc.stop()
            return await ctx.send(embed=ok(f"{SKIP} Skipped."))
        await ctx.send(embed=err("Nothing is playing."))

    @commands.hybrid_command(name="stop", description="Stop music and clear the queue")
    @commands.guild_only()
    async def stop(self, ctx):
        vc = ctx.voice_client
        if not vc:
            return await ctx.send(embed=err("I'm not in a voice channel."))
        p = self.player(ctx.guild.id)
        p.queue.clear()
        p.loop, p.skipped, p.current = "off", True, None
        if vc.is_playing() or vc.is_paused():
            vc.stop()
        await self._finish_np(p)
        await ctx.send(embed=ok(f"{STOP} Stopped and cleared the queue."))

    @commands.hybrid_command(name="queue", aliases=["q"], description="Show the queue")
    @commands.guild_only()
    async def queue(self, ctx, page: int = 1):
        p = self.player(ctx.guild.id)
        if not p.current and not p.queue:
            return await ctx.send(embed=err("Queue is empty."))
        await ctx.send(embed=self.queue_embed(ctx.guild, page))

    @commands.hybrid_command(name="nowplaying", aliases=["current", "playing"], description="Show the current song")
    @commands.guild_only()
    async def nowplaying(self, ctx):
        p = self.player(ctx.guild.id)
        if not p.current:
            return await ctx.send(embed=err("Nothing is playing."))
        await ctx.send(embed=self.np_embed(ctx.guild, p.current))

    @commands.hybrid_command(name="volume", aliases=["vol"], description="Set volume (1-150)")
    @commands.guild_only()
    async def volume(self, ctx, level: int):
        if not 1 <= level <= 150:
            return await ctx.send(embed=err("Volume must be between 1 and 150."))
        p = self.player(ctx.guild.id)
        p.volume = level / 100
        vc = ctx.voice_client
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = p.volume
        await ctx.send(embed=ok(f"{VOLUME} Volume set to **{level}%**"))

    @commands.hybrid_command(name="loop", aliases=["repeat", "lp"], description="Loop: off / track / queue")
    @commands.guild_only()
    async def loop(self, ctx, mode: str = None):
        p = self.player(ctx.guild.id)
        order = ["off", "track", "queue"]
        mode = (mode or order[(order.index(p.loop) + 1) % 3]).lower()
        if mode not in order:
            return await ctx.send(embed=err("Use `off`, `track` or `queue`."))
        p.loop = mode
        await ctx.send(embed=ok(f"{LOOP} Loop mode: **{mode}**"))

    @commands.hybrid_command(name="shuffle", description="Shuffle the queue")
    @commands.guild_only()
    async def shuffle(self, ctx):
        p = self.player(ctx.guild.id)
        if len(p.queue) < 2:
            return await ctx.send(embed=err("Not enough songs to shuffle."))
        items = list(p.queue)
        random.shuffle(items)
        p.queue = deque(items)
        await ctx.send(embed=ok(f"{SHUFFLE} Queue shuffled."))

    @commands.hybrid_command(name="remove", description="Remove a song from the queue by position")
    @commands.guild_only()
    async def remove(self, ctx, position: int):
        p = self.player(ctx.guild.id)
        if not 1 <= position <= len(p.queue):
            return await ctx.send(embed=err("Invalid position."))
        items = list(p.queue)
        t = items.pop(position - 1)
        p.queue = deque(items)
        await ctx.send(embed=ok(f"Removed **{t.title[:70]}**"))

    @commands.hybrid_command(name="clearqueue", aliases=["cq"], description="Clear the queue")
    @commands.guild_only()
    async def clearqueue(self, ctx):
        self.player(ctx.guild.id).queue.clear()
        await ctx.send(embed=ok("Queue cleared."))

    @commands.hybrid_command(name="skipto", description="Skip to a position in the queue")
    @commands.guild_only()
    async def skipto(self, ctx, position: int):
        p = self.player(ctx.guild.id)
        if not 1 <= position <= len(p.queue):
            return await ctx.send(embed=err("Invalid position."))
        for _ in range(position - 1):
            p.queue.popleft()
        p.skipped = True
        if ctx.voice_client:
            ctx.voice_client.stop()
        await ctx.send(embed=ok(f"Skipped to position **{position}**."))

    @commands.hybrid_command(name="filter", aliases=["fx"], description="Audio filter: pro/off/bass/clear/loud/nightcore/slowed/8d/vaporwave")
    @commands.guild_only()
    async def filter(self, ctx, name: str = "pro"):
        name = name.lower()
        if name not in FILTERS:
            return await ctx.send(embed=err("Filters: " + ", ".join(f"`{k}`" for k in FILTERS)))
        self.player(ctx.guild.id).filter = name
        await ctx.send(embed=ok(f"Filter **{name}** — applies from the next song (use `skip`)."))

    @commands.hybrid_command(name="autoplay", aliases=["ap"], description="Auto-play similar songs when the queue ends (free for everyone)")
    @commands.guild_only()
    async def autoplay(self, ctx):
        p = self.player(ctx.guild.id)
        p.autoplay = not p.autoplay
        p.text = p.text or ctx.channel
        await ctx.send(embed=ok(f"{INFINITY} Autoplay **{'enabled' if p.autoplay else 'disabled'}**."))

    @commands.hybrid_command(name="247", aliases=["stay"], description="Toggle 24/7 mode: ZYRO stays in the voice channel (free for everyone)")
    @commands.guild_only()
    async def twentyfour(self, ctx):
        vc = await self.ensure_voice(ctx)
        if not vc:
            return
        p = self.player(ctx.guild.id)
        p.twentyfour7 = not p.twentyfour7
        async with aiosqlite.connect(DB) as db:
            if p.twentyfour7:
                await db.execute("INSERT OR REPLACE INTO vc247 VALUES (?, ?)", (ctx.guild.id, vc.channel.id))
            else:
                await db.execute("DELETE FROM vc247 WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok(f"24/7 mode **{'enabled' if p.twentyfour7 else 'disabled'}**"))

    @commands.hybrid_command(name="grab", aliases=["save"], description="Send the current song to your DMs")
    @commands.guild_only()
    async def grab(self, ctx):
        p = self.player(ctx.guild.id)
        if not p.current:
            return await ctx.send(embed=err("Nothing is playing."))
        try:
            await ctx.author.send(embed=embed(f"{MUSIC} Saved song", f"**[{p.current.title}]({p.current.url})**\nFrom **{ctx.guild.name}**"))
            await ctx.send(embed=ok("Sent to your DMs."))
        except Exception:
            await ctx.send(embed=err("Your DMs are closed."))

    @commands.command(name="voicecheck", aliases=["vcheck", "musiccheck"])
    async def voicecheck(self, ctx):
        """Developer/Admin: checks opus, ffmpeg, PyNaCl, davey (voice encryption)."""
        from cogs import z_team
        if await z_team.level(ctx.author.id) < 2:
            return
        def ver(mod):
            try:
                m = __import__(mod)
                return getattr(m, "__version__", "installed")
            except Exception as e:
                return f"❌ missing ({type(e).__name__})"
        import yt_dlp
        lines = [f"Opus loaded: **{ensure_opus()}**", f"ffmpeg: `{shutil.which('ffmpeg') or '❌ not found'}`",
                 f"PyNaCl: `{ver('nacl')}`", f"davey (voice E2EE): `{ver('davey')}`",
                 f"discord.py: `{discord.__version__}`", f"yt-dlp: `{getattr(yt_dlp.version, '__version__', '?')}`",
                 f"YouTube cookies: `{'yes' if COOKIE_FILE else 'no'}`"]
        await ctx.send(embed=embed("🔧 Voice check", "\n".join(lines)))

    @commands.hybrid_command(name="musicsetup", aliases=["setupmusic"], description="Create a music request channel")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def musicsetup(self, ctx):
        ch = await ctx.guild.create_text_channel("🎵・zyro-music", topic="Type a song name or link here — ZYRO will play it. Join a voice channel first!", reason="ZYRO music setup")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO music_setup VALUES (?, ?)", (ctx.guild.id, ch.id))
            await db.commit()
        self.setup_channels[ctx.guild.id] = ch.id
        await ch.send(embed=embed(f"{MUSIC} ZYRO Music", "Just type a **song name** or **link** here and join a voice channel.\nUse the buttons under *Now Playing* to control the player."))
        await ctx.send(embed=ok(f"Music channel created: {ch.mention}"))

    @commands.hybrid_command(name="musicsetupremove", description="Remove the music request channel setting")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def musicsetupremove(self, ctx):
        self.setup_channels.pop(ctx.guild.id, None)
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM music_setup WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok("Music channel setting removed (the channel itself was not deleted)."))

    # ---------- listeners ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild or self.setup_channels.get(message.guild.id) != message.channel.id:
            return
        ctx = await self.bot.get_context(message)
        if ctx.valid or not message.content.strip():
            return
        content = message.content.strip()
        try:
            await message.delete()
        except Exception:
            pass
        await self._play(ctx, content)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        guild, vc = member.guild, member.guild.voice_client
        if not vc or member.bot or self.player(guild.id).twentyfour7:
            return
        if not [m for m in vc.channel.members if not m.bot]:
            await asyncio.sleep(60)
            vc = guild.voice_client
            if vc and not [m for m in vc.channel.members if not m.bot]:
                p = self.players.pop(guild.id, None)
                if p:
                    await self._finish_np(p)
                await vc.disconnect()

    @commands.Cog.listener()
    async def on_ready(self):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT guild_id, channel_id FROM vc247") as cur:
                rows = await cur.fetchall()
        for gid, cid in rows:
            g = self.bot.get_guild(gid)
            ch = g.get_channel(cid) if g else None
            if ch and not g.voice_client:
                try:
                    await ch.connect(self_deaf=True)
                    self.player(gid).twentyfour7 = True
                except Exception:
                    pass


async def setup(bot):
    await bot.add_cog(Music(bot))
