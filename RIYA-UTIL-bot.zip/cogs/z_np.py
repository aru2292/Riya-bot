"""ZYRO NoPrefix — separate from premium:  &np @user 6month | 3m | 1d | lifetime   riya util team"""
import re
import datetime
import aiosqlite
import discord
from discord.ext import commands
from config import CORE_DB
from zutil import embed, ok, err
from cogs import z_team

FOREVER = "2099-12-31T00:00:00"
UNIT = {"h": 3600, "hr": 3600, "hour": 3600, "hours": 3600, "d": 86400, "day": 86400, "days": 86400, "w": 604800, "week": 604800,
        "weeks": 604800, "m": 2592000, "mo": 2592000, "month": 2592000, "months": 2592000, "y": 31536000, "yr": 31536000,
        "year": 31536000, "years": 31536000}


def parse(text: str):
    t = (text or "").lower().replace(" ", "")
    if t in ("lifetime", "life", "perm", "permanent", "forever"):
        return 0
    m = re.fullmatch(r"(\d+)([a-z]+)", t)
    if m and m.group(2) in UNIT and int(m.group(1)) > 0:
        return int(m.group(1)) * UNIT[m.group(2)]
    return None


def label(sec: int) -> str:
    if sec == 0:
        return "Lifetime"
    d = sec / 86400
    if d < 1:
        return f"{int(sec // 3600)} Hour(s)"
    if d >= 365 and d % 365 == 0:
        return f"{int(d // 365)} Year(s)"
    if d % 30 == 0:
        return f"{int(d // 30)} Month(s)"
    if d % 7 == 0:
        return f"{int(d // 7)} Week(s)"
    return f"{int(d)} Day(s)"


def when(iso: str) -> str:
    try:
        dt = datetime.datetime.fromisoformat(iso)
        return "**Never (Lifetime)**" if dt.year >= 2099 else f"<t:{int(dt.replace(tzinfo=datetime.timezone.utc).timestamp())}:F> (<t:{int(dt.replace(tzinfo=datetime.timezone.utc).timestamp())}:R>)"
    except Exception:
        return iso


class NoPrefix(commands.Cog, name="NoPrefix"):
    """Give people the power to use commands without a prefix (separate from premium)."""

    def __init__(self, bot):
        self.bot = bot

    async def _staff(self, ctx) -> bool:
        if await z_team.level(ctx.author.id) < 2:
            await ctx.send(embed=err("Only the **Developer** or an **Admin** can manage No-Prefix."))
            return False
        return True

    @commands.group(name="np", aliases=["noprefix", "nop"], invoke_without_command=True)
    async def np(self, ctx, user: discord.User = None, *, duration: str = None):
        """np @user 6month — give No-Prefix (1d 2d 7d 1m 3m 4m 6m 1y lifetime)."""
        if user is None or duration is None:
            p = ctx.prefix
            return await ctx.send(embed=embed("⚡ No-Prefix", f"`{p}np @user 1d` • `2d` • `7d` • `1m` • `3m` • `4m` • `6month` • `1y` • `lifetime`\n"
                                              f"`{p}np remove @user` • `{p}np list` • `{p}np check [@user]`\n\n*Separate from premium.*"))
        if not await self._staff(ctx):
            return
        sec = parse(duration)
        if sec is None:
            return await ctx.send(embed=err("Duration examples: `1d` `2d` `7d` `1m` `3m` `4m` `6month` `1y` `lifetime`"))
        if user.bot:
            return await ctx.send(embed=err("Bots can't get No-Prefix."))
        now = datetime.datetime.utcnow()
        async with aiosqlite.connect(CORE_DB) as db:
            async with db.execute("SELECT expires FROM noprefix WHERE user_id=?", (user.id,)) as c:
                row = await c.fetchone()
            if sec == 0:
                exp = FOREVER
            else:
                base = now
                try:
                    cur = datetime.datetime.fromisoformat(row[0]) if row else None
                    if cur and cur > now:
                        base = cur                      # stack on top of running No-Prefix
                except Exception:
                    pass
                exp = (base + datetime.timedelta(seconds=sec)).isoformat()
            await db.execute("INSERT OR REPLACE INTO noprefix (user_id, plan, added_by, added_at, expires) VALUES (?, ?, ?, ?, ?)",
                             (user.id, f"NP {label(sec)}", ctx.author.id, now.isoformat(), exp))
            await db.commit()
        try:
            await user.send(embed=embed("⚡ You received No-Prefix!", f"**Plan:** {label(sec)}\n**Expires:** {when(exp)}\n**Given by:** {ctx.author}\n\n"
                                        "Now you can use every ZYRO command **without a prefix** — just type `help`, `play`, `serverinfo`…", 0x9B59B6))
            dm = "📩 DM sent."
        except Exception:
            dm = "⚠️ Couldn't DM them."
        await ctx.send(embed=ok(f"No-Prefix **{label(sec)}** given to {user.mention} • expires {when(exp)}\n{dm}"), allowed_mentions=discord.AllowedMentions.none())

    @np.command(name="remove", aliases=["rm", "del"])
    async def np_remove(self, ctx, user: discord.User):
        if not await self._staff(ctx):
            return
        async with aiosqlite.connect(CORE_DB) as db:
            cur = await db.execute("DELETE FROM noprefix WHERE user_id=?", (user.id,))
            await db.commit()
        await ctx.send(embed=ok(f"No-Prefix removed from {user.mention}.") if cur.rowcount else err("That user has no No-Prefix."),
                       allowed_mentions=discord.AllowedMentions.none())

    @np.command(name="list", aliases=["ls"])
    async def np_list(self, ctx):
        if not await self._staff(ctx):
            return
        async with aiosqlite.connect(CORE_DB) as db:
            async with db.execute("SELECT user_id, plan, expires FROM noprefix ORDER BY expires LIMIT 40") as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("Nobody has No-Prefix."))
        await ctx.send(embed=embed(f"⚡ No-Prefix users ({len(rows)})", "\n".join(f"<@{u}> — {p} — {when(e)}" for u, p, e in rows)),
                       allowed_mentions=discord.AllowedMentions.none())

    @np.command(name="check", aliases=["me", "status"])
    async def np_check(self, ctx, user: discord.User = None):
        target = user or ctx.author
        if target.id != ctx.author.id and await z_team.level(ctx.author.id) < 2:
            return await ctx.send(embed=err("You can only check your own No-Prefix."))
        async with aiosqlite.connect(CORE_DB) as db:
            async with db.execute("SELECT plan, expires FROM noprefix WHERE user_id=?", (target.id,)) as c:
                r = await c.fetchone()
        await ctx.send(embed=ok(f"{target.mention}: **{r[0]}** — expires {when(r[1])}") if r else err("No active No-Prefix."),
                       allowed_mentions=discord.AllowedMentions.none())


async def setup(bot):
    await bot.add_cog(NoPrefix(bot))
