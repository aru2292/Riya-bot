# RIYA UTIL

**All-in-one Discord bot** — Antinuke • Music • VoiceMaster • Moderation • Fun • Economy • Leveling • Tickets • and more.

**Developed by:** riya util team

---

## Quick Start (Docker / Railway / Render / any host)

1. Put your bot **TOKEN** and **OWNER_IDS** in environment variables.
2. Deploy this repo (Dockerfile is ready).
3. Bot comes online automatically.

### Required Environment Variables
```
TOKEN=your_bot_token_here
OWNER_IDS=your_discord_user_id
PREFIX=&
```

Optional:
```
SUPPORT_LINK=https://discord.gg/your-invite
INVITE_LINK=your_oauth_invite_url
DATA_DIR=/data
LOG_CHANNEL_ID=0
```

### Discord Developer Portal
- Enable **Server Members Intent**
- Enable **Message Content Intent**
- Invite with Administrator permission
- Put the bot role at the **TOP** of the role list

---

## Features
- Full Antinuke + Panic mode
- Music (download-first, works on most hosts)
- VoiceMaster / temp voice channels
- Automod, tickets, giveaways, economy, leveling
- Premium system, No-Prefix, custom emojis
- Slash commands + prefix commands

## Credits
**riya util team**

---

## Self-host tip
Use a host that supports Docker + persistent volume for `/data` (SQLite databases).

