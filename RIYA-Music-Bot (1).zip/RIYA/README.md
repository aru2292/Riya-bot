<h1 align="center">RIYA ᝰ.ᐟ</h1>
<p align="center"><b>Your all-in-one premium music companion</b><br>Developed by <b>ARIAN</b></p>

---

## ✨ Features

- 🎵 **Music** — play from YouTube, Spotify links, SoundCloud and more; queue, loop, shuffle, seek, previous, skip-to, autoplay, 24/7 mode, lyrics, history, "grab" a song to your DMs
- 🎛️ **Filters** — bass boost, nightcore, vaporwave, genre EQs and more (`filters` folder)
- 📜 **Playlists** — create / load / edit your own playlists, Spotify linking
- 📖 **Help center** — `help` opens an interactive menu (categories → commands → usage)
- 🚀 **No-prefix** — the owner can grant / revoke no-prefix access to any user (permanent or timed)
- 💎 **Premium** — the owner can grant / revoke premium for users and servers (timed or permanent)
- 🎨 **Server bot profile** — a **premium server** can change the bot's **dp (avatar), banner, nickname and bio** just for that server
- 🧱 Slash commands **and** prefix commands, cooldowns, anti-abuse, blacklist, sharding

---

## 🚀 Quick start (GitHub Codespaces)

```bash
unzip -o RIYA-Music-Bot.zip && cd RIYA && npm install && npm run setup
npm start
```

`npm run setup` asks for your **bot token**, **client ID** and **your Discord user ID** and writes the `.env` for you.

In the Discord Developer Portal → your app → **Bot**, turn ON:
**Server Members Intent** and **Message Content Intent**.

Invite link (replace `CLIENT_ID`):
`https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands`

After the bot is online, run **once** (as owner): `.updateslash` — this registers the `/` commands.

> ⚠️ Never upload your real `.env` to GitHub. It is already in `.gitignore`.

---

## 👑 Owner commands

Owners are the IDs in `OWNER_IDS` (`.env`). Default prefix is `.` — change it in `.env`.

| Command | What it does |
|---|---|
| `noprefix grant @user [duration]` | Give a user no-prefix (default: permanent) |
| `noprefix revoke @user` | Take it back |
| `noprefix list` / `noprefix check @user` | See who has it |
| `premium grant user <@user/id> [duration]` | Premium for a user |
| `premium grant guild [serverId] [duration]` | Premium for a server (leave id empty = this server) |
| `premium revoke user <id>` / `premium revoke guild [id]` | Remove premium (a server's custom bot profile is reset automatically) |
| `premium stats` / `premium cleanup` | Overview / remove expired |
| `blacklist ...` | Ban a user or server from the bot |
| `updateslash` | Register / refresh slash commands |
| `rl` | Reload commands |

**Durations:** `30m` `12h` `7d` `2w` `1mo` `1y` `perm`

---

## 🎨 Server bot profile (premium servers)

Needs **Manage Server** permission + server premium:

```
.botprofile avatar <image link>        (or attach an image)
.botprofile banner <image link>        (or attach an image)
.botprofile nick My Music Bot
.botprofile bio Playing the best music
.botprofile reset
```

Slash version: `/botprofile`. When a server's premium ends, its custom profile is reset automatically.

---

## 🎧 Music server (Lavalink)

RIYA plays music through a **Lavalink** server. By default `.env` points to a free public node — public nodes can be slow or go offline.

- `.nodes` shows whether your music node is **online**.
- Add a backup node with the `LAVALINK2_*` values in `.env` (used automatically if the first is down).
- Want your own? `npm run lavalink` (needs Java 17+) downloads and starts a local Lavalink on port 2333 — then use `LAVALINK_HOST=localhost`, `LAVALINK_PORT=2333`, `LAVALINK_PASSWORD=youshallnotpass`, `LAVALINK_SECURE=false`.
- Text searches try several sources in order (`SEARCH_SOURCES` in `.env`) so a missing Spotify plugin does not break `play`.

---

## 🖼️ Custom emojis

The emojis in `src/config/emoji.js` are custom emojis. A bot can show them only if it shares a server with them (or they are uploaded as Application Emojis). If you see `:tick:` text instead of icons: upload your own emojis and replace the IDs in that file, or set `USE_UNICODE_EMOJI=true` in `.env`.

---

## 🛠️ Troubleshooting

| Problem | Fix |
|---|---|
| Bot online but commands do nothing | Enable **Message Content Intent**; check the prefix (`.help`) |
| `/` commands missing | Run `.updateslash` once, wait a minute |
| "Couldn't find track" | Run `.nodes` — if offline, change the Lavalink node |
| Premium command says "Premium required" | Owner must run `premium grant guild` in that server |

---

<p align="center">RIYA ᝰ.ᐟ • Developed by <b>ARIAN</b></p>
