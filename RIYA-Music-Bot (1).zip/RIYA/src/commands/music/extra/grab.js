import { MessageFlags } from "discord.js";

import { Command } from "#structures/classes/Command";
import emoji from "#config/emoji";
import { logger } from "#utils/logger";
import {
  brandContainer,
  addText,
  addSeparator,
  addFooter,
  respond,
  userOf,
} from "#utils/ui";

const fmt = (ms) => {
  if (!ms || ms < 0) return "Live";
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
};

class GrabCommand extends Command {
  constructor() {
    super({
      name: "grab",
      description: "Save the current song to your DMs",
      usage: "grab",
      aliases: ["save", "dmsong"],
      category: "music",
      examples: ["grab"],
      cooldown: 5,
      playerRequired: true,
      playingRequired: true,
      enabledSlash: true,
      slashData: { name: "grab", description: "Save the current song to your DMs" },
    });
  }

  async execute({ message, pm }) {
    return this._run(message, pm);
  }

  async slashExecute({ interaction, pm }) {
    return this._run(interaction, pm);
  }

  async _run(ctx, pm) {
    const track = pm.currentTrack;
    const user = userOf(ctx);
    const info = track.info;

    const card = brandContainer();
    addText(card, `### ${emoji.get("music")} Saved Song`);
    addSeparator(card);
    addText(
      card,
      `**${info.title}**\n` +
        `├─ **Artist:** ${info.author || "Unknown"}\n` +
        `├─ **Length:** ${fmt(info.duration)}\n` +
        `├─ **Saved from:** ${ctx.guild.name}\n` +
        `└─ ${info.uri ? `[Open link](${info.uri})` : "No link available"}`,
    );
    addFooter(card);

    try {
      await user.send({ components: [card], flags: MessageFlags.IsComponentsV2 });
      return respond(ctx, this._note(`${emoji.get("check")} Sent **${info.title}** to your DMs.`), { ephemeral: true });
    } catch (error) {
      logger.debug("GrabCommand", `DM failed: ${error.message}`);
      return respond(ctx, this._note(`${emoji.get("cross")} I can't DM you — please enable DMs from server members.`), { ephemeral: true });
    }
  }

  _note(text) {
    const c = brandContainer();
    addText(c, text);
    return c;
  }
}

export default new GrabCommand();
