import { Command } from "#structures/classes/Command";
import emoji from "#config/emoji";
import { brandContainer, addText, addSeparator, addFooter, respond } from "#utils/ui";

class SkipToCommand extends Command {
  constructor() {
    super({
      name: "skipto",
      description: "Jump straight to a song in the queue",
      usage: "skipto <position>",
      aliases: ["jump", "jumpto", "st"],
      category: "music",
      examples: ["skipto 5", "jump 3"],
      cooldown: 3,
      voiceRequired: true,
      sameVoiceRequired: true,
      playerRequired: true,
      playingRequired: true,
      enabledSlash: true,
      slashData: {
        name: "skipto",
        description: "Jump straight to a song in the queue",
        options: [
          { name: "position", description: "Queue position to jump to", type: 4, required: true, min_value: 1 },
        ],
      },
    });
  }

  async execute({ message, args, pm }) {
    return this._run(message, pm, parseInt(args[0], 10));
  }

  async slashExecute({ interaction, pm }) {
    return this._run(interaction, pm, interaction.options.getInteger("position"));
  }

  async _run(ctx, pm, position) {
    const size = pm.queueSize;
    if (!Number.isInteger(position) || position < 1 || position > size) {
      return respond(
        ctx,
        this._panel(
          size === 0
            ? `${emoji.get("cross")} The queue is empty.`
            : `${emoji.get("cross")} Give a position between **1** and **${size}**.`,
        ),
      );
    }

    const target = pm.queue.tracks[position - 1];
    await pm.player.skip(position);

    return respond(
      ctx,
      this._panel(`${emoji.get("music")} Jumped to **#${position}** — **${target?.info?.title ?? "track"}**`),
    );
  }

  _panel(text) {
    const c = brandContainer();
    addText(c, `### ${emoji.get("next")} Skip To`);
    addSeparator(c);
    addText(c, text);
    addFooter(c);
    return c;
  }
}

export default new SkipToCommand();
