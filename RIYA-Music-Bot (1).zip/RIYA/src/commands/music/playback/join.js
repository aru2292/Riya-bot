import { PermissionFlagsBits } from "discord.js";

import { Command } from "#structures/classes/Command";
import emoji from "#config/emoji";
import { logger } from "#utils/logger";
import { brandContainer, addText, addSeparator, addFooter, respond, userOf } from "#utils/ui";

class JoinCommand extends Command {
  constructor() {
    super({
      name: "join",
      description: "Make the bot join your voice channel",
      usage: "join",
      aliases: ["connect", "summon", "j"],
      category: "music",
      examples: ["join", "summon"],
      cooldown: 3,
      voiceRequired: true,
      enabledSlash: true,
      slashData: { name: "join", description: "Make the bot join your voice channel" },
    });
  }

  async execute({ client, message }) {
    return this._join(client, message);
  }

  async slashExecute({ client, interaction }) {
    return this._join(client, interaction);
  }

  async _join(client, ctx) {
    const member = ctx.member;
    const voice = member.voice.channel;
    const me = ctx.guild.members.me;

    const existing = client.music.getPlayer(ctx.guild.id);
    if (existing && existing.voiceChannelId === voice.id) {
      return respond(ctx, this._panel(`${emoji.get("info")} I'm already in <#${voice.id}> — use \`play\` to start music!`));
    }

    const perms = voice.permissionsFor(me);
    if (!perms?.has([PermissionFlagsBits.Connect, PermissionFlagsBits.Speak])) {
      return respond(ctx, this._panel(`${emoji.get("cross")} I need **Connect** and **Speak** permissions in <#${voice.id}>.`));
    }

    try {
      const player = await client.music.createPlayer({
        guildId: ctx.guild.id,
        textChannelId: ctx.channel.id,
        voiceChannelId: voice.id,
      });
      if (!player) throw new Error("player not created");
      return respond(
        ctx,
        this._panel(`${emoji.get("headphones")} Joined <#${voice.id}> — ready for music! Use \`play <song>\`.`),
      );
    } catch (error) {
      logger.error("JoinCommand", `Join failed for ${userOf(ctx).id}`, error);
      return respond(ctx, this._panel(`${emoji.get("cross")} Could not join. Is a Lavalink node connected?`));
    }
  }

  _panel(text) {
    const c = brandContainer();
    addText(c, `### ${emoji.get("music")} Join`);
    addSeparator(c);
    addText(c, text);
    addFooter(c);
    return c;
  }
}

export default new JoinCommand();
