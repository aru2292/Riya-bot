import { Command } from "#structures/classes/Command";
import { config } from "#config/config";
import { db } from "#database/DatabaseManager";
import emoji from "#config/emoji";
import { logger } from "#utils/logger";
import {
  brandContainer,
  addText,
  addSeparator,
  addFooter,
  respond,
  parseDuration,
  parseId,
  formatDuration,
} from "#utils/ui";

const USAGE =
  `**${emoji.get("info")} Usage**\n` +
  `├─ \`noprefix grant <@user|id> [duration]\` — give no-prefix\n` +
  `├─ \`noprefix revoke <@user|id>\` — take it back\n` +
  `├─ \`noprefix check <@user|id>\` — see one user\n` +
  `└─ \`noprefix list\` — everyone who has it\n\n` +
  `**Durations:** \`30m\` \`12h\` \`7d\` \`2w\` \`1mo\` \`1y\` \`perm\` (default: permanent)`;

class NoPrefixCommand extends Command {
  constructor() {
    super({
      name: "noprefix",
      description: "Grant or revoke no-prefix access for a user (Owner Only)",
      usage: "noprefix <grant|revoke|check|list> [user] [duration]",
      aliases: ["nop", "nopgrant"],
      category: "developer",
      examples: [
        "noprefix grant @user perm",
        "noprefix grant 123456789012345678 30d",
        "noprefix revoke @user",
        "noprefix list",
      ],
      cooldown: 2,
      ownerOnly: true,
    });
  }

  async execute({ message, args }) {
    const action = (args[0] || "").toLowerCase();

    try {
      switch (action) {
        case "grant":
        case "add":
        case "give":
          return await this._grant(message, args.slice(1));
        case "revoke":
        case "remove":
        case "take":
          return await this._revoke(message, args.slice(1));
        case "check":
        case "info":
          return await this._check(message, args.slice(1));
        case "list":
        case "all":
          return await this._list(message);
        default:
          return this._panel(message, "No-Prefix Manager", USAGE);
      }
    } catch (error) {
      logger.error("NoPrefix", "Command failed", error);
      return this._panel(message, "Error", `${emoji.get("cross")} ${error.message}`);
    }
  }

  async _grant(message, args) {
    const target = parseId(args[0]) || message.mentions?.users?.first()?.id;
    if (!target) return this._panel(message, "Missing User", `Mention a user or give an ID.\n\n${USAGE}`);

    const durationArg = args[1] || "perm";
    const ms = parseDuration(durationArg);
    if (ms === undefined) {
      return this._panel(message, "Invalid Duration", `\`${durationArg}\` is not valid.\n\n${USAGE}`);
    }

    const expiresAt = ms === null ? null : Date.now() + ms;
    db.setNoPrefix(target, true, expiresAt);

    return this._panel(
      message,
      "No-Prefix Granted",
      `${emoji.get("check")} <@${target}> (\`${target}\`) can now use commands **without a prefix**.\n\n` +
        `├─ **Duration:** ${ms === null ? "Permanent" : formatDuration(ms)}\n` +
        `└─ **Expires:** ${expiresAt ? `<t:${Math.floor(expiresAt / 1000)}:R>` : "Never"}`,
    );
  }

  async _revoke(message, args) {
    const target = parseId(args[0]) || message.mentions?.users?.first()?.id;
    if (!target) return this._panel(message, "Missing User", `Mention a user or give an ID.\n\n${USAGE}`);

    if (!db.getNoPrefixInfo(target)) {
      return this._panel(message, "Nothing To Revoke", `${emoji.get("info")} <@${target}> does not have no-prefix access.`);
    }

    db.setNoPrefix(target, false, null);
    return this._panel(
      message,
      "No-Prefix Revoked",
      `${emoji.get("check")} Removed no-prefix access from <@${target}> (\`${target}\`).`,
    );
  }

  async _check(message, args) {
    const target = parseId(args[0]) || message.mentions?.users?.first()?.id;
    if (!target) return this._panel(message, "Missing User", `Mention a user or give an ID.\n\n${USAGE}`);

    const info = db.getNoPrefixInfo(target);
    if (!info) return this._panel(message, "No-Prefix Status", `${emoji.get("cross")} <@${target}> does **not** have no-prefix.`);

    return this._panel(
      message,
      "No-Prefix Status",
      `${emoji.get("check")} <@${target}> has no-prefix.\n└─ **Expires:** ${
        info.expiresAt ? `<t:${Math.floor(info.expiresAt / 1000)}:R>` : "Never (permanent)"
      }`,
    );
  }

  async _list(message) {
    const rows = db.getAllNoPrefix();
    if (!rows.length) {
      return this._panel(message, "No-Prefix Users", `${emoji.get("info")} Nobody has no-prefix right now.`);
    }

    const shown = rows.slice(0, 25);
    const lines = shown.map((r, i) => {
      const exp = r.no_prefix_expiry ? `<t:${Math.floor(r.no_prefix_expiry / 1000)}:R>` : "permanent";
      return `\`${String(i + 1).padStart(2, "0")}\` <@${r.id}> — ${exp}`;
    });
    if (rows.length > shown.length) lines.push(`…and **${rows.length - shown.length}** more`);

    return this._panel(message, `No-Prefix Users (${rows.length})`, lines.join("\n"));
  }

  _panel(message, title, body) {
    const c = brandContainer();
    addText(c, `### ${emoji.get("crown")} ${title}`);
    addSeparator(c);
    addText(c, body);
    addFooter(c);
    return respond(message, c);
  }
}

export default new NoPrefixCommand();
