import { Command } from "#structures/classes/Command";
import { db } from "#database/DatabaseManager";
import emoji from "#config/emoji";
import { brandContainer, addText, addSeparator, addFooter, respond, userOf } from "#utils/ui";

const when = (exp) => (exp ? `until <t:${Math.floor(exp / 1000)}:D> (<t:${Math.floor(exp / 1000)}:R>)` : "permanent");

class PerksCommand extends Command {
  constructor() {
    super({
      name: "perks",
      description: "See your premium, this server's premium and no-prefix status",
      usage: "perks",
      aliases: ["mypremium", "premiumstatus", "myperks", "pstatus"],
      category: "premium",
      examples: ["perks"],
      cooldown: 5,
      enabledSlash: true,
      slashData: { name: "perks", description: "See your premium, server premium and no-prefix status" },
    });
  }

  async execute({ message }) {
    return respond(message, this._build(message));
  }

  async slashExecute({ interaction }) {
    return respond(interaction, this._build(interaction));
  }

  _build(ctx) {
    const user = userOf(ctx);
    const userPrem = db.isUserPremium(user.id);
    const guildPrem = db.isGuildPremium(ctx.guild.id);
    const nop = db.getNoPrefixInfo(user.id);
    const profile = db.hasCustomBotProfile(ctx.guild.id);

    const c = brandContainer();
    addText(c, `### ${emoji.get("gem")} Your Perks`);
    addSeparator(c);
    addText(
      c,
      `${emoji.get("user")} **User premium:** ${userPrem ? `${emoji.get("check")} ${when(userPrem.expiresAt)}` : `${emoji.get("cross")} none`}\n` +
        `${emoji.get("server")} **Server premium:** ${guildPrem ? `${emoji.get("check")} ${when(guildPrem.expiresAt)}` : `${emoji.get("cross")} none`}\n` +
        `${emoji.get("rocket")} **No-prefix:** ${nop ? `${emoji.get("check")} ${when(nop.expiresAt)}` : `${emoji.get("cross")} none`}\n` +
        `${emoji.get("paint")} **Custom bot profile here:** ${profile ? "yes" : "no"}`,
    );
    addSeparator(c);
    addText(
      c,
      `${emoji.get("info")} **Server premium** unlocks \`botprofile\` (change the bot's dp, banner, nick & bio in your server), bigger queues and more.\n` +
        `Want premium or no-prefix? Contact the developer — **ARIAN**.`,
    );
    addFooter(c);
    return c;
  }
}

export default new PerksCommand();
