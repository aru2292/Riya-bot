import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MessageFlags,
  PermissionFlagsBits,
} from "discord.js";

import { Command } from "#structures/classes/Command";
import { config } from "#config/config";
import { db } from "#database/DatabaseManager";
import emoji from "#config/emoji";
import { logger } from "#utils/logger";
import { isOwner } from "#utils/permissionUtil";
import {
  imageUrlToDataUri,
  patchBotProfile,
  resetBotProfile,
} from "#utils/BotProfile";
import {
  brandContainer,
  addText,
  addSeparator,
  addFooter,
  respond,
  userOf,
} from "#utils/ui";

const ACTIONS = ["view", "avatar", "banner", "nick", "bio", "reset"];

class BotProfileCommand extends Command {
  constructor() {
    super({
      name: "botprofile",
      description: "Change the bot's server profile — dp, banner, nickname, bio (Server Premium)",
      usage: "botprofile <avatar|banner|nick|bio|reset> [link / text]",
      aliases: ["bp", "setbot", "serverprofile", "botdp", "botbanner"],
      category: "premium",
      examples: [
        "botprofile avatar https://i.imgur.com/xyz.png",
        "botprofile banner (attach an image)",
        "botprofile nick My Music Bot",
        "botprofile bio Playing the best music",
        "botprofile reset all",
      ],
      cooldown: 10,
      userPermissions: [PermissionFlagsBits.ManageGuild],
      enabledSlash: true,
      slashData: {
        name: "botprofile",
        description: "Change the bot's dp, banner, nickname or bio in this server (Server Premium)",
        options: [
          {
            name: "action",
            description: "What do you want to change?",
            type: 3,
            required: false,
            choices: [
              { name: "View current profile", value: "view" },
              { name: "Set avatar (dp)", value: "avatar" },
              { name: "Set banner", value: "banner" },
              { name: "Set nickname", value: "nick" },
              { name: "Set bio", value: "bio" },
              { name: "Reset everything", value: "reset" },
            ],
          },
          { name: "image", description: "Image for avatar / banner", type: 11, required: false },
          { name: "link", description: "Image link for avatar / banner", type: 3, required: false },
          { name: "text", description: "Text for nickname / bio", type: 3, required: false },
        ],
      },
    });
  }

  async execute({ client, message, args }) {
    const action = (args[0] || "view").toLowerCase();
    const rest = args.slice(1);
    const attachment = message.attachments?.first();
    return this._run(client, message, {
      action: ACTIONS.includes(action) ? action : "help",
      imageUrl: attachment?.contentType?.startsWith("image/") ? attachment.url : rest.find((x) => /^https?:\/\//i.test(x)),
      text: rest.join(" ").trim(),
    });
  }

  async slashExecute({ client, interaction }) {
    const action = interaction.options.getString("action") || "view";
    const attachment = interaction.options.getAttachment("image");
    return this._run(client, interaction, {
      action,
      imageUrl: attachment?.url || interaction.options.getString("link") || null,
      text: interaction.options.getString("text") || "",
    });
  }

  async _run(client, ctx, { action, imageUrl, text }) {
    const guild = ctx.guild;
    const user = userOf(ctx);

    if (!db.isGuildPremium(guild.id) && !isOwner(user.id)) {
      return respond(ctx, this._premiumRequired(), { ephemeral: true });
    }

    if (action === "help") return respond(ctx, this._panel(guild, this._usage()));
    if (action === "view") return this._view(ctx, client, guild);

    // Image / text actions can take a moment (download + Discord PATCH)
    if (typeof ctx.deferReply === "function" && !ctx.deferred && !ctx.replied) {
      await ctx.deferReply();
    }

    try {
      switch (action) {
        case "avatar":
        case "banner": {
          if (!imageUrl) {
            return respond(ctx, this._panel(guild, `${emoji.get("cross")} Attach an image or give an image link.\n\n${this._usage()}`));
          }
          const dataUri = await imageUrlToDataUri(imageUrl);
          await patchBotProfile(client, guild.id, { [action]: dataUri });
          db.saveBotProfile(guild.id, { [`${action}_set`]: 1 }, user.id);
          return respond(
            ctx,
            this._panel(guild, `${emoji.get("check")} Bot **${action === "avatar" ? "dp (avatar)" : "banner"}** updated for **${guild.name}**.\n\n-# It can take a few seconds to show up in Discord.`),
          );
        }

        case "nick": {
          if (!text) return respond(ctx, this._panel(guild, `${emoji.get("cross")} Give a nickname (max 32 characters).`));
          if (text.length > 32) return respond(ctx, this._panel(guild, `${emoji.get("cross")} Nickname must be 32 characters or fewer.`));
          await patchBotProfile(client, guild.id, { nick: text });
          db.saveBotProfile(guild.id, { nick: text }, user.id);
          return respond(ctx, this._panel(guild, `${emoji.get("check")} Bot nickname is now **${text}**.`));
        }

        case "bio": {
          if (!text) return respond(ctx, this._panel(guild, `${emoji.get("cross")} Give some text for the bio (max 190 characters).`));
          if (text.length > 190) return respond(ctx, this._panel(guild, `${emoji.get("cross")} Bio must be 190 characters or fewer.`));
          await patchBotProfile(client, guild.id, { bio: text });
          db.saveBotProfile(guild.id, { bio: text }, user.id);
          return respond(ctx, this._panel(guild, `${emoji.get("check")} Bot bio updated for this server.`));
        }

        case "reset": {
          await resetBotProfile(client, guild.id);
          return respond(ctx, this._panel(guild, `${emoji.get("check")} Bot profile reset — dp, banner, nickname and bio are back to default.`));
        }
      }
    } catch (error) {
      logger.error("BotProfile", `Failed in ${guild.id}`, error);
      return respond(
        ctx,
        this._panel(guild, `${emoji.get("cross")} **Could not update the profile**\n\`${String(error.message).slice(0, 300)}\``),
      );
    }
  }

  async _view(ctx, client, guild) {
    const profile = db.getBotProfile(guild.id);
    const premium = db.isGuildPremium(guild.id);
    const me = guild.members.me;

    const lines =
      `**${emoji.get("server")} Server:** ${guild.name}\n` +
      `**${emoji.get("gem")} Premium:** ${premium ? (premium.expiresAt ? `until <t:${Math.floor(premium.expiresAt / 1000)}:D>` : "Permanent") : "Owner access"}\n\n` +
      `├─ **DP (avatar):** ${profile?.avatar_set ? "Custom" : "Default"}\n` +
      `├─ **Banner:** ${profile?.banner_set ? "Custom" : "Default"}\n` +
      `├─ **Nickname:** ${profile?.nick || me?.nickname || "Default"}\n` +
      `└─ **Bio:** ${profile?.bio || "Not set"}\n\n` +
      this._usage();

    const container = this._panel(guild, lines, false);
    const resetBtn = new ButtonBuilder()
      .setCustomId("botprofile_reset")
      .setLabel("Reset All")
      .setStyle(ButtonStyle.Danger);
    container.addActionRowComponents(new ActionRowBuilder().addComponents(resetBtn));
    addSeparator(container);
    addFooterInline(container);

    const msg = await respond(ctx, container);
    if (!msg?.createMessageComponentCollector) return;

    const authorId = userOf(ctx).id;
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60_000,
      filter: (i) => i.user.id === authorId,
    });
    let done = false;
    collector.on("collect", async (i) => {
      done = true;
      try {
        await i.deferUpdate();
        await resetBotProfile(client, guild.id);
        await i.editReply({
          components: [this._panel(guild, `${emoji.get("check")} Bot profile reset to default.`)],
          flags: MessageFlags.IsComponentsV2,
        });
      } catch (e) {
        logger.error("BotProfile", "Reset button failed", e);
      }
      collector.stop();
    });
    collector.on("end", () => done || msg.edit({ components: [this._panel(guild, "Session ended — run the command again.")], flags: MessageFlags.IsComponentsV2 }).catch(() => {}));
  }

  _usage() {
    return (
      `**${emoji.get("info")} How to use**\n` +
      `├─ \`botprofile avatar <link>\` or attach an image\n` +
      `├─ \`botprofile banner <link>\` or attach an image\n` +
      `├─ \`botprofile nick <name>\`\n` +
      `├─ \`botprofile bio <text>\`\n` +
      `└─ \`botprofile reset\``
    );
  }

  _panel(guild, body, footer = true) {
    const c = brandContainer();
    addText(c, `### ${emoji.get("paint")} Bot Profile`);
    addSeparator(c);
    addText(c, body);
    if (footer) addFooter(c);
    return c;
  }

  _premiumRequired() {
    const c = brandContainer();
    addText(c, `### ${emoji.get("gem")} Server Premium Required`);
    addSeparator(c);
    addText(
      c,
      `Changing the bot's **dp, banner, nickname and bio** is a premium feature for this server.\n\n` +
        `${emoji.get("crown")} Ask **${config.bot.developer}** (the developer) to enable premium for your server.\n` +
        `${emoji.get("link")} Support: ${config.links.supportServer}`,
    );
    addFooter(c);
    return c;
  }
}

function addFooterInline(container) {
  // footer without a second separator (the caller already added one)
  addText(container, `-# ${config.bot.name} • Developed by ${config.bot.developer}`);
}

export default new BotProfileCommand();
