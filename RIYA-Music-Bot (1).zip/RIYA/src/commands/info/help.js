import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
  PermissionsBitField,
  SectionBuilder,
  StringSelectMenuBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder,
} from "discord.js";

import { Command } from "#structures/classes/Command";
import { config } from "#config/config";
import { db } from "#database/DatabaseManager";
import emoji from "#config/emoji";
import { logger } from "#utils/logger";
import { isOwner } from "#utils/permissionUtil";
import {
  brandContainer,
  addText,
  addSeparator,
  addFooter,
  respond,
  userOf,
} from "#utils/ui";

// ----------------------------------------------------------------------
// Category presentation. Key = top-level folder inside src/commands.
// Any new folder you add is picked up automatically (with a default look).
// ----------------------------------------------------------------------
const CATEGORY_META = {
  music: { emoji: "🎵", label: "Music", desc: "Play, queue, search, lyrics, autoplay & more" },
  filters: { emoji: "🎛️", label: "Filters", desc: "Bass boost, nightcore, genre EQ & sound effects" },
  playlists: { emoji: "📜", label: "Playlists", desc: "Create, load and manage your own playlists" },
  Spotify: { emoji: "🟢", label: "Spotify", desc: "Link your Spotify and play your playlists" },
  settings: { emoji: "⚙️", label: "Settings", desc: "Prefix, volume, 24/7 mode and server setup" },
  premium: { emoji: "💎", label: "Premium", desc: "Server profile (dp / banner) and premium perks" },
  info: { emoji: "ℹ️", label: "Info", desc: "Ping, invite, support, bot info" },
  developer: { emoji: "👑", label: "Owner", desc: "Owner-only controls (premium, no-prefix, blacklist)", ownerOnly: true },
};

const topLevel = (category = "") => String(category).split(/[\\/]/)[0] || "misc";
const pretty = (s) => s.charAt(0).toUpperCase() + s.slice(1);

class HelpCommand extends Command {
  constructor() {
    super({
      name: "help",
      description: "Open the RIYA help center — every command, neatly organised",
      usage: "help [command | category]",
      aliases: ["h", "commands", "cmds", "menu"],
      category: "info",
      examples: ["help", "help play", "help filters", "h skip"],
      cooldown: 3,
      enabledSlash: true,
      slashData: {
        name: "help",
        description: "Open the help center or get help for one command",
        options: [
          {
            name: "command",
            description: "Command (or category) to get help for",
            type: 3,
            required: false,
            autocomplete: true,
          },
        ],
      },
    });
  }

  async execute({ client, message, args }) {
    return this._start(client, message, args.join(" ").trim());
  }

  async slashExecute({ client, interaction }) {
    return this._start(client, interaction, interaction.options.getString("command") || "");
  }

  async autocomplete({ client, interaction }) {
    const focused = interaction.options.getFocused().toLowerCase();
    const owner = isOwner(interaction.user.id);
    const names = [...client.commandHandler.commands.values()]
      .filter((c) => owner || topLevel(c.category) !== "developer")
      .map((c) => c.name)
      .filter((n) => n.toLowerCase().includes(focused))
      .sort()
      .slice(0, 25);
    await interaction.respond(names.map((n) => ({ name: n, value: n }))).catch(() => {});
  }

  // --------------------------------------------------------------------
  async _start(client, ctx, query) {
    try {
      const user = userOf(ctx);
      const owner = isOwner(user.id);
      const cats = this._categories(client, owner);

      let first;
      if (query) {
        const q = query.toLowerCase();
        const command = this._findCommand(client, q);
        const catKey = [...cats.keys()].find((k) => k.toLowerCase() === q);
        if (command && (owner || topLevel(command.category) !== "developer")) {
          first = this._commandPage(client, ctx, command);
        } else if (catKey) {
          first = this._categoryPage(client, ctx, cats, catKey);
        } else {
          first = this._errorPage(`${emoji.get("cross")} I couldn't find a command or category called \`${query.slice(0, 40)}\`.`, cats);
        }
      } else {
        first = this._homePage(client, ctx, cats);
      }

      const msg = await respond(ctx, first);
      if (msg?.createMessageComponentCollector) this._collect(client, ctx, msg, user.id, owner);
    } catch (error) {
      logger.error("HelpCommand", "Failed to open help", error);
      await respond(ctx, this._errorPage(`${emoji.get("cross")} Could not load the help center.`)).catch(() => {});
    }
  }

  _collect(client, ctx, msg, authorId, owner) {
    const collector = msg.createMessageComponentCollector({
      time: 5 * 60_000,
      filter: (i) => {
        if (i.user.id === authorId) return true;
        i.reply({ content: `${emoji.get("lock")} This help menu belongs to someone else — run \`help\` yourself.`, flags: MessageFlags.Ephemeral }).catch(() => {});
        return false;
      },
    });

    collector.on("collect", async (i) => {
      try {
        await i.deferUpdate();
        const cats = this._categories(client, owner);

        if (i.customId === "riyahelp_close") {
          await msg.delete().catch(() => {});
          collector.stop("closed");
          return;
        }

        let page;
        if (i.customId === "riyahelp_home") {
          page = this._homePage(client, ctx, cats);
        } else if (i.customId === "riyahelp_cat") {
          page = this._categoryPage(client, ctx, cats, i.values[0]);
        } else if (i.customId.startsWith("riyahelp_cmd_")) {
          const command = client.commandHandler.commands.get(i.values[0]);
          page = command ? this._commandPage(client, ctx, command) : this._homePage(client, ctx, cats);
        } else if (i.customId.startsWith("riyahelp_back_")) {
          page = this._categoryPage(client, ctx, cats, i.customId.replace("riyahelp_back_", ""));
        } else {
          return;
        }
        await i.editReply({ components: [page] });
      } catch (error) {
        logger.error("HelpCommand", "Interaction failed", error);
      }
    });

    collector.on("end", async (_c, reason) => {
      if (reason === "closed") return;
      // Disable the menu quietly after it times out
      try {
        const cats = this._categories(client, owner);
        const page = this._homePage(client, ctx, cats, true);
        await msg.edit({ components: [page], flags: MessageFlags.IsComponentsV2 });
      } catch {}
    });
  }

  // --------------------------------------------------------------------
  // data
  // --------------------------------------------------------------------
  _categories(client, owner) {
    const map = new Map();
    for (const cmd of client.commandHandler.commands.values()) {
      const key = topLevel(cmd.category);
      if (key === "developer" && !owner) continue;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(cmd);
    }
    // stable order: meta order first, then anything new
    const order = Object.keys(CATEGORY_META);
    return new Map(
      [...map.entries()].sort(([a], [b]) => {
        const ia = order.includes(a) ? order.indexOf(a) : 99;
        const ib = order.includes(b) ? order.indexOf(b) : 99;
        return ia - ib || a.localeCompare(b);
      }),
    );
  }

  _meta(key) {
    return CATEGORY_META[key] || { emoji: "📦", label: pretty(key), desc: "Extra commands" };
  }

  _findCommand(client, q) {
    const { commands, aliases } = client.commandHandler;
    return commands.get(q) || commands.get(aliases.get(q));
  }

  _prefix(ctx) {
    try {
      return db.getPrefixes(ctx.guild.id)[0] || config.prefix;
    } catch {
      return config.prefix;
    }
  }

  // --------------------------------------------------------------------
  // pages
  // --------------------------------------------------------------------
  _homePage(client, ctx, cats, disabled = false) {
    const prefix = this._prefix(ctx);
    const total = [...cats.values()].reduce((n, l) => n + l.length, 0);
    const c = brandContainer();

    if (config.assets.helpBanner) {
      try {
        c.addMediaGalleryComponents(
          new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(config.assets.helpBanner)),
        );
      } catch {}
    }

    c.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# ${emoji.get("music")} ${config.bot.name}\n` +
              `*${config.bot.tagline}*\n\n` +
              `${emoji.get("right")} **Prefix:** \`${prefix}\`  •  **Slash:** \`/\`\n` +
              `${emoji.get("sparkle")} **Commands:** \`${total}\`  •  **Servers:** \`${client.guilds.cache.size}\``,
          ),
        )
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(config.assets.helpThumbnail)),
    );

    addSeparator(c, true);

    const lines = [...cats.entries()].map(([key, list]) => {
      const m = this._meta(key);
      return `${m.emoji} **${m.label}** \`${list.length}\`\n-# ${m.desc}`;
    });
    addText(c, lines.join("\n"));

    addSeparator(c);
    addText(
      c,
      `${emoji.get("info")} Pick a category below, or use \`${prefix}help <command>\` for details.\n` +
        `${emoji.get("heart")} Tip: type \`${prefix}play <song>\` after joining a voice channel to start!`,
    );

    c.addActionRowComponents(this._categoryMenu(cats, null, disabled));
    c.addActionRowComponents(this._linkRow(client, disabled));
    addFooter(c);
    return c;
  }

  _categoryPage(client, ctx, cats, key) {
    const list = cats.get(key);
    if (!list) return this._errorPage(`${emoji.get("cross")} That category does not exist.`, cats);

    const prefix = this._prefix(ctx);
    const m = this._meta(key);
    const c = brandContainer();

    addText(c, `# ${m.emoji} ${m.label}\n${m.desc}`);
    addSeparator(c);

    // group by sub-folder (music/queue → "Queue")
    const groups = new Map();
    for (const cmd of list) {
      const sub = String(cmd.category).split(/[\\/]/)[1] || "";
      if (!groups.has(sub)) groups.set(sub, []);
      groups.get(sub).push(cmd);
    }

    const chunks = [];
    for (const [sub, cmds] of [...groups.entries()].sort(([a], [b]) => a.localeCompare(b))) {
      const names = cmds
        .map((x) => x.name)
        .sort()
        .map((n) => `\`${n}\``)
        .join(" ");
      chunks.push(`${sub ? `**${pretty(sub)}**\n` : ""}${names}`);
    }
    let body = chunks.join("\n\n");
    if (body.length > 3000) body = body.slice(0, 2990) + "…";
    addText(c, body);

    addSeparator(c);
    addText(c, `-# Select a command below to see usage, aliases and examples • \`${prefix}help <command>\``);

    c.addActionRowComponents(this._commandMenu(key, list));
    c.addActionRowComponents(this._categoryMenu(cats, key));
    c.addActionRowComponents(this._navRow());
    addFooter(c);
    return c;
  }

  _commandPage(client, ctx, command) {
    const prefix = this._prefix(ctx);
    const key = topLevel(command.category);
    const m = this._meta(key);
    const c = brandContainer();

    const badges = [];
    if (command.ownerOnly) badges.push(`${emoji.get("crown")} Owner only`);
    if (command.guildPrem) badges.push(`${emoji.get("gem")} Server premium`);
    if (command.userPrem) badges.push(`${emoji.get("gem")} User premium`);
    if (command.anyPrem) badges.push(`${emoji.get("gem")} Premium`);
    if (command.voiceRequired) badges.push(`${emoji.get("headphones")} Voice channel`);
    if (command.enabledSlash) badges.push(`${emoji.get("sparkle")} Slash`);

    const perms = command.userPermissions?.length
      ? new PermissionsBitField(command.userPermissions).toArray().join(", ")
      : null;

    let text =
      `# ${m.emoji} ${command.name}\n${command.description}\n\n` +
      `**${emoji.get("right")} Usage:** \`${prefix}${command.usage || command.name}\`\n`;
    if (command.aliases?.length) text += `**${emoji.get("folder")} Aliases:** ${command.aliases.map((a) => `\`${a}\``).join(" ")}\n`;
    text += `**${emoji.get("reset")} Cooldown:** ${command.cooldown}s\n`;
    if (perms) text += `**${emoji.get("shield")} You need:** ${perms}\n`;
    if (command.enabledSlash && command.slashData) {
      const n = Array.isArray(command.slashData.name) ? command.slashData.name.join(" ") : command.slashData.name;
      text += `**${emoji.get("sparkle")} Slash:** \`/${n}\`\n`;
    }
    if (badges.length) text += `\n${badges.join("  •  ")}`;

    addText(c, text);

    if (command.examples?.length) {
      addSeparator(c);
      addText(c, `**${emoji.get("info")} Examples**\n` + command.examples.slice(0, 5).map((e) => `\`${prefix}${e}\``).join("\n"));
    }

    c.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`riyahelp_back_${key}`).setLabel(`Back to ${m.label}`).setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("riyahelp_home").setLabel("Home").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("riyahelp_close").setLabel("Close").setStyle(ButtonStyle.Danger),
      ),
    );
    addFooter(c);
    return c;
  }

  _errorPage(text, cats = null) {
    const c = brandContainer();
    addText(c, `### ${emoji.get("cross")} Help`);
    addSeparator(c);
    addText(c, text);
    if (cats) c.addActionRowComponents(this._categoryMenu(cats, null));
    addFooter(c);
    return c;
  }

  // --------------------------------------------------------------------
  // components
  // --------------------------------------------------------------------
  _categoryMenu(cats, selected, disabled = false) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("riyahelp_cat")
      .setPlaceholder("📂  Choose a category…")
      .setDisabled(disabled)
      .addOptions(
        [...cats.entries()].slice(0, 25).map(([key, list]) => {
          const m = this._meta(key);
          return {
            label: m.label,
            description: `${list.length} commands • ${m.desc}`.slice(0, 100),
            value: key,
            emoji: { name: m.emoji },
            default: key === selected,
          };
        }),
      );
    return new ActionRowBuilder().addComponents(menu);
  }

  _commandMenu(key, list) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`riyahelp_cmd_${key}`)
      .setPlaceholder("🔎  Pick a command for details…")
      .addOptions(
        [...list]
          .sort((a, b) => a.name.localeCompare(b.name))
          .slice(0, 25)
          .map((cmd) => ({
            label: cmd.name,
            description: String(cmd.description || "").slice(0, 100) || "No description",
            value: cmd.name,
          })),
      );
    return new ActionRowBuilder().addComponents(menu);
  }

  _navRow() {
    return new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("riyahelp_home").setLabel("Home").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("riyahelp_close").setLabel("Close").setStyle(ButtonStyle.Danger),
    );
  }

  _linkRow(client, disabled = false) {
    const row = new ActionRowBuilder();
    const clientId = config.clientId || client.user?.id;
    row.addComponents(
      new ButtonBuilder()
        .setLabel("Invite")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=8&scope=bot%20applications.commands`),
      new ButtonBuilder().setLabel("Support").setStyle(ButtonStyle.Link).setURL(config.links.supportServer),
    );
    if (!disabled) {
      row.addComponents(new ButtonBuilder().setCustomId("riyahelp_close").setLabel("Close").setStyle(ButtonStyle.Danger));
    }
    return row;
  }
}

export default new HelpCommand();
