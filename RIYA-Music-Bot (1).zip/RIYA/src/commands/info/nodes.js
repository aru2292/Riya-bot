import { Command } from "#structures/classes/Command";
import emoji from "#config/emoji";
import { brandContainer, addText, addSeparator, addFooter, respond } from "#utils/ui";

const mb = (b) => `${((b || 0) / 1024 / 1024).toFixed(0)} MB`;
const up = (ms) => {
  const s = Math.floor((ms || 0) / 1000);
  return `${Math.floor(s / 86400)}d ${Math.floor((s % 86400) / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
};

class NodesCommand extends Command {
  constructor() {
    super({
      name: "nodes",
      description: "Live music-node (Lavalink) status and bot statistics",
      usage: "nodes",
      aliases: ["node", "lavalink", "musicstatus"],
      category: "info",
      examples: ["nodes"],
      cooldown: 10,
      enabledSlash: true,
      slashData: { name: "nodes", description: "Live music-node (Lavalink) status and bot statistics" },
    });
  }

  async execute({ client, message }) {
    return respond(message, this._build(client));
  }

  async slashExecute({ client, interaction }) {
    return respond(interaction, this._build(client));
  }

  _build(client) {
    const nodes = [...(client.music?.lavalink?.nodeManager?.nodes?.values?.() ?? [])];
    const players = client.music?.lavalink?.players?.size ?? 0;

    const nodeLines = nodes.length
      ? nodes
          .map((n) => {
            const ok = n.connected;
            return (
              `${ok ? emoji.get("check") : emoji.get("cross")} **${n.id}** — ${ok ? "online" : "offline"}\n` +
              (ok && n.stats
                ? `-# players ${n.stats.playingPlayers}/${n.stats.players} • memory ${mb(n.stats.memory?.used)} • uptime ${up(n.stats.uptime)}`
                : `-# not connected — check LAVALINK_* values in .env`)
            );
          })
          .join("\n")
      : `${emoji.get("cross")} No music node configured.`;

    const c = brandContainer();
    addText(c, `### ${emoji.get("headphones")} Stats`);
    addSeparator(c);
    addText(
      c,
      `**Bot**\n` +
        `├─ **Servers:** ${client.guilds.cache.size}\n` +
        `├─ **Active players:** ${players}\n` +
        `├─ **Uptime:** ${up(client.uptime)}\n` +
        `├─ **Ping:** ${Math.round(client.ws.ping)}ms\n` +
        `└─ **Memory:** ${mb(process.memoryUsage().rss)}`,
    );
    addSeparator(c);
    addText(c, `**Music nodes**\n${nodeLines}`);
    addFooter(c);
    return c;
  }
}

export default new NodesCommand();
