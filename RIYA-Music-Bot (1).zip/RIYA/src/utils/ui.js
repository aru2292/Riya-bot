import {
	ContainerBuilder,
	MessageFlags,
	TextDisplayBuilder,
	SeparatorBuilder,
	SeparatorSpacingSize,
} from 'discord.js';

import { config } from '#config/config';

/** A Components-V2 container with the RIYA accent colour already applied. */
export function brandContainer() {
	return new ContainerBuilder().setAccentColor(config.bot.color);
}

/** Small grey footer line used at the bottom of panels. */
export function footerLine() {
	return `-# ${config.bot.name} • Developed by ${config.bot.developer}`;
}

export function addSeparator(container, large = false) {
	return container.addSeparatorComponents(
		new SeparatorBuilder().setSpacing(
			large ? SeparatorSpacingSize.Large : SeparatorSpacingSize.Small,
		),
	);
}

export function addText(container, content) {
	return container.addTextDisplayComponents(
		new TextDisplayBuilder().setContent(content),
	);
}

export function addFooter(container) {
	addSeparator(container);
	return addText(container, footerLine());
}

/** Compact one-shot panel: title, body, footer. */
export function simplePanel(title, body) {
	const c = brandContainer();
	addText(c, `### ${title}`);
	addSeparator(c);
	addText(c, body);
	addFooter(c);
	return c;
}

/** "5 minutes" / "2 days" style helper. */
export function formatDuration(ms) {
	if (ms == null) return 'Permanent';
	const s = Math.floor(ms / 1000);
	const d = Math.floor(s / 86400);
	const h = Math.floor((s % 86400) / 3600);
	const m = Math.floor((s % 3600) / 60);
	const parts = [];
	if (d) parts.push(`${d}d`);
	if (h) parts.push(`${h}h`);
	if (m && !d) parts.push(`${m}m`);
	return parts.join(' ') || '<1m';
}

/**
 * Parses "30m", "12h", "7d", "2w", "1mo", "1y", "perm" -> ms | null (permanent) | undefined (invalid)
 */
export function parseDuration(input) {
	if (!input) return undefined;
	const t = String(input).toLowerCase().trim();
	if (['perm', 'permanent', 'forever', 'lifetime', 'life', 'never'].includes(t)) return null;
	const m = t.match(/^(\d+)\s*(m|min|h|d|w|mo|y)$/);
	if (!m) return undefined;
	const n = parseInt(m[1], 10);
	if (!n) return undefined;
	const unit = { m: 60e3, min: 60e3, h: 3600e3, d: 86400e3, w: 7 * 86400e3, mo: 30 * 86400e3, y: 365 * 86400e3 }[m[2]];
	return n * unit;
}

/** "<@123>", "<@!123>", "123" -> "123" | null */
export function parseId(raw) {
	if (!raw) return null;
	const m = String(raw).match(/^<@!?(\d{15,25})>$|^(\d{15,25})$/);
	return m ? m[1] || m[2] : null;
}


/**
 * Replies to either a Message (prefix command) or an Interaction (slash command)
 * with Components-V2 content and returns the sent message.
 */
export async function respond(ctx, components, { ephemeral = false } = {}) {
	const list = Array.isArray(components) ? components : [components];
	const isInteraction = typeof ctx.isChatInputCommand === 'function' || 'commandName' in ctx;

	if (!isInteraction) {
		return ctx.reply({ components: list, flags: MessageFlags.IsComponentsV2 });
	}

	const flags = ephemeral
		? MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
		: MessageFlags.IsComponentsV2;

	if (ctx.deferred || ctx.replied) {
		await ctx.editReply({ components: list, flags: MessageFlags.IsComponentsV2 });
	} else {
		await ctx.reply({ components: list, flags });
	}
	return ctx.fetchReply().catch(() => null);
}

export const userOf = ctx => ctx.author || ctx.user;
