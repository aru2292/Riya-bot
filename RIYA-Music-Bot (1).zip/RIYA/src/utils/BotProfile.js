import { Routes } from 'discord.js';

import { db } from '#database/DatabaseManager';
import { logger } from '#utils/logger';

const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Map([
	['image/png', 'png'],
	['image/jpeg', 'jpeg'],
	['image/jpg', 'jpeg'],
	['image/gif', 'gif'],
	['image/webp', 'webp'],
]);

/** Downloads an image URL and returns a data URI Discord accepts. Throws a user-friendly Error. */
export async function imageUrlToDataUri(url) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		throw new Error('That is not a valid link.');
	}
	if (!['http:', 'https:'].includes(parsed.protocol)) {
		throw new Error('Only http(s) image links are supported.');
	}

	const res = await fetch(parsed, {
		signal: AbortSignal.timeout(15000),
		headers: { 'User-Agent': 'RIYA-Bot/1.0' },
	});
	if (!res.ok) throw new Error(`Could not download the image (HTTP ${res.status}).`);

	const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
	if (!ALLOWED.has(type)) {
		throw new Error('The link must be a PNG, JPG, GIF or WEBP image.');
	}

	const buf = Buffer.from(await res.arrayBuffer());
	if (buf.length > MAX_IMAGE_BYTES) {
		throw new Error('Image is too large (max 8 MB).');
	}
	return `data:${type};base64,${buf.toString('base64')}`;
}

/** PATCH /guilds/{id}/members/@me  — the per-server bot profile */
export async function patchBotProfile(client, guildId, body) {
	return client.rest.patch(Routes.guildMember(guildId, '@me'), { body });
}

/** Removes every customisation the server made (dp, banner, nick, bio). */
export async function resetBotProfile(client, guildId) {
	try {
		await patchBotProfile(client, guildId, {
			nick: null,
			avatar: null,
			banner: null,
			bio: null,
		});
	} catch (error) {
		// Even if Discord refuses (missing perms / bot kicked) we still clear our record.
		logger.warn('BotProfile', `Discord reset failed for ${guildId}: ${error.message}`);
	}
	db.clearBotProfile(guildId);
}

/**
 * Safety net: any server that still has a custom bot profile but no longer has
 * premium gets reset. Called on an interval from the ready event.
 */
export async function sweepExpiredProfiles(client) {
	try {
		for (const guild of client.guilds.cache.values()) {
			if (db.hasCustomBotProfile(guild.id) && !db.isGuildPremium(guild.id)) {
				logger.info('BotProfile', `Premium ended for ${guild.name}; resetting bot profile.`);
				await resetBotProfile(client, guild.id);
			}
		}
	} catch (error) {
		logger.error('BotProfile', 'Sweep failed', error);
	}
}
