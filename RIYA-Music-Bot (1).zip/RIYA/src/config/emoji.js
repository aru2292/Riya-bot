// ----------------------------------------------------------------------
// RIYA ᝰ.ᐟ  —  emoji sheet
// ----------------------------------------------------------------------
// The custom emojis below are KEPT exactly as they were.
// A bot can only show a custom emoji if it is in the server that owns it
// (or the emoji is uploaded as an "Application Emoji" in the Developer Portal).
// If the emojis show up as plain text like :tick:, either
//   1) upload your own emojis and replace the IDs below, or
//   2) set USE_UNICODE_EMOJI=true in .env to use the built-in fallbacks.
// ----------------------------------------------------------------------

const custom = {
  check: "<:tick:1430462544698540144>",
  info: "<:info:1430462548452442207>",
  cross: "<:crosss:1430463116767924264>",
  add: "<:add:1430462540021895208>",
  reset: "<:reset:1430462556039938130>",
  folder: "<:folder:1430462546883776622>",
  openfolder: "<:open:1430462552470720522>",
  music: "<a:music:1430462537786200115>",
  right: "<:right:1430462542118916126>",
  left: "<:left:1430462550398468138>",
  loading: "<a:loading:1430462535865208874>",
};

const unicode = {
  check: "✅",
  info: "ℹ️",
  cross: "❌",
  add: "➕",
  reset: "🔄",
  folder: "📁",
  openfolder: "📂",
  music: "🎵",
  right: "▶️",
  left: "◀️",
  loading: "⏳",
};

// Extra decoration emojis (plain unicode, work everywhere)
const extra = {
  crown: "👑",
  star: "⭐",
  sparkle: "✨",
  heart: "💜",
  fire: "🔥",
  gem: "💎",
  headphones: "🎧",
  mic: "🎤",
  queue: "📜",
  filter: "🎛️",
  settings: "⚙️",
  shield: "🛡️",
  lock: "🔒",
  unlock: "🔓",
  user: "👤",
  server: "🏠",
  link: "🔗",
  clock: "🕒",
  home: "🏡",
  speaker: "🔊",
  mute: "🔇",
  loop: "🔁",
  shuffle: "🔀",
  next: "⏭️",
  prev: "⏮️",
  pause: "⏸️",
  play: "▶️",
  stop: "⏹️",
  heartbeat: "💓",
  rocket: "🚀",
  paint: "🎨",
  bot: "🤖",
  dev: "🧑‍💻",
};

const useUnicode = process.env.USE_UNICODE_EMOJI === "true";
const base = useUnicode ? unicode : custom;

export const emoji = {
  ...base,
  ...extra,
  get(name, fallback = "") {
    return this[name] && typeof this[name] === "string" ? this[name] : fallback;
  },
};

export default emoji;
