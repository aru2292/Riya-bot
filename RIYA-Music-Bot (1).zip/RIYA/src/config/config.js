import dotenv from 'dotenv';
dotenv.config();

// Resolves the running bot's avatar (set by the client on startup).
const botAvatar = () =>
  globalThis.__riyaClient?.user?.displayAvatarURL?.({ extension: 'png', size: 512 }) ||
  'https://cdn.discordapp.com/embed/avatars/0.png';

export const config = {
  // ------------------------------------------------------------------
  // BRANDING
  // ------------------------------------------------------------------
  bot: {
    name: 'RIYA ᝰ.ᐟ',          // Display name used in text/embeds
    shortName: 'RIYA',         // Used where fancy glyphs cannot render (image cards)
    developer: 'ARIAN',        // Developer credit
    tagline: 'Your all-in-one premium music companion',
    color: 0xc86bfa,           // Brand accent colour (containers / embeds)
  },

  // Bot authentication token from Discord Developer Portal
  token: process.env.DISCORD_TOKEN,
  
  // Discord application client ID (found in Developer Portal)
  clientId: process.env.CLIENT_ID,
  
  // Command prefix for text-based commands (default: '.')
  prefix: process.env.PREFIX || '.',
  
  // Array of Discord user IDs with owner privileges
  // Multiple IDs should be comma-separated in .env file
  ownerIds: (process.env.OWNER_IDS || '').split(',').map(id => id.trim()).filter(Boolean),
  
  // Lavalink node configuration for music streaming
  // Supports multiple nodes for load balancing and redundancy
  nodes: [
    {
      id: "main-node",
      host: process.env.LAVALINK_HOST,
      port: parseInt(process.env.LAVALINK_PORT) || 2333,
      authorization: process.env.LAVALINK_PASSWORD,
      secure: process.env.LAVALINK_SECURE === 'true', // Use true for WSS connections
      retryAmount: 5, // Number of connection retry attempts
      retryDelay: 3000, // Delay between retries in milliseconds
    },
    // Optional backup node (set LAVALINK2_HOST in .env to enable)
    ...(process.env.LAVALINK2_HOST
      ? [
          {
            id: "backup-node",
            host: process.env.LAVALINK2_HOST,
            port: parseInt(process.env.LAVALINK2_PORT) || 2333,
            authorization: process.env.LAVALINK2_PASSWORD,
            secure: process.env.LAVALINK2_SECURE === 'true',
            retryAmount: 5,
            retryDelay: 3000,
          },
        ]
      : []),
  ],
  
  // Application environment (development/production)
  environment: process.env.NODE_ENV || 'development',
  
  // Enable debug logging (auto-enabled in development mode)
  debug: process.env.DEBUG === 'true' || process.env.NODE_ENV === 'development',
  
  // Database file paths for different data types
  // Using .bread extension for Better-SQLite3 databases
  database: {
    guild: './database/data/guild.bread',
    user: './database/data/user.bread',
    premium: './database/data/premium.bread',
    antiabuse: './database/data/antiabuse.bread',
    playlists: './database/data/playlists.bread',
  },
  
  // External links and resources
  links: {
    supportServer: process.env.SUPPORT_SERVER_URL || "https://discord.com/app"
  },
  
  // Bot presence/status configuration
  status: {
    name: process.env.STATUS_TEXT || '.help | RIYA ᝰ.ᐟ',
    status: process.env.STATUS_TYPE || 'online', // online, idle, dnd, invisible
    type: 'CUSTOM' // Activity type
  },
  
  // Embed color scheme (hex values)
  colors: {
    info: '#3498db',     // Blue - informational messages
    success: '#2ecc71',  // Green - success messages
    warning: '#f39c12',  // Orange - warning messages
    error: '#e74c3c'     // Red - error messages
  },
  
  // Discord webhook configuration for logging bot events
  webhook: {
    enabled: process.env.WEBHOOK_ENABLED !== 'false',
    url: process.env.WEBHOOK_URL || null,
    username: process.env.WEBHOOK_USERNAME || 'Bot Logger',
    avatarUrl: process.env.WEBHOOK_AVATAR_URL || null,
    // Configure which log levels should be sent to webhook
    levels: {
      info: {
        enabled: process.env.WEBHOOK_INFO_ENABLED !== 'false'
      },
      success: {
        enabled: process.env.WEBHOOK_SUCCESS_ENABLED !== 'false'
      },
      warning: {
        enabled: process.env.WEBHOOK_WARNING_ENABLED !== 'false'
      },
      error: {
        enabled: process.env.WEBHOOK_ERROR_ENABLED !== 'false'
      },
      debug: {
        enabled: process.env.WEBHOOK_DEBUG_ENABLED === 'true'
      }
    }
  },
  
  // Bot feature toggles
  features: {
    stay247: true // Keep bot in voice channel 24/7 when enabled
  },
  
  // Queue limitations based on user tier
  queue: {
    maxSongs: {
      free: 50,      // Maximum songs for free users
      premium: 200   // Maximum songs for premium users
    }
  },
  
  // Default image assets for embeds.
  // If you do not set these in .env, the bot's own avatar is used automatically.
  assets: {
    get defaultTrackArtwork() {
      return process.env.DEFAULT_TRACK_ARTWORK || botAvatar();
    },
    get defaultThumbnail() {
      return process.env.DEFAULT_THUMBNAIL || botAvatar();
    },
    get helpThumbnail() {
      return process.env.HELP_THUMBNAIL || botAvatar();
    },
    // Optional wide banner shown inside the help center (leave empty to hide)
    get helpBanner() {
      return process.env.HELP_BANNER || null;
    },
  },

  // Spotify API credentials for track searching
  // Get these from https://developer.spotify.com/dashboard
  spotify: {
    clientId: process.env.SPOTIFY_CLIENT_ID,
    clientSecret: process.env.SPOTIFY_CLIENT_SECRET
  },
  
  // Last.fm API configuration for music metadata
  // Get API key from https://www.last.fm/api
  lastfm: {
    apiKey: process.env.LASTFM_API_KEY
  },
  
  // Music search configuration
  search: {
    maxResults: 6, // Maximum search results to display
    // Default sources to search from (YouTube, Spotify, Apple Music, SoundCloud)
    defaultSources: ['ytsearch'],
    // Order in which sources are tried when a text search finds nothing.
    // Override with SEARCH_SOURCES=ytmsearch,ytsearch,spsearch,scsearch in .env
    fallbackSources: (process.env.SEARCH_SOURCES || 'ytmsearch,ytsearch,spsearch,scsearch')
      .split(',')
      .map(x => x.trim())
      .filter(Boolean),
  },
  
  // Music player default settings
  player: {
    defaultVolume: 100,        // Default volume level (0-100)
    seekStep: 10000,           // Seek forward/backward step in milliseconds (10s)
    maxHistorySize: 50,        // Maximum number of previously played tracks to keep
    // 24/7 mode configuration
    stay247: {
      reconnectDelay: 5000,         // Delay before reconnection attempt (ms)
      maxReconnectAttempts: 3,      // Maximum reconnection attempts
      checkInterval: 30000          // Interval to check connection status (ms)
    }
  },
  
  // Bot metadata
  watermark: 'RIYA ᝰ.ᐟ • Developed by ARIAN',
  version: '1.0.0'
};
