import { REST } from '@discordjs/rest';
import { ClusterClient, getInfo } from 'discord-hybrid-sharding';
import {
	Client,
	GatewayIntentBits,
	Collection,
	Partials,
	Options,
} from 'discord.js';

import { config } from '#config/config';
import { db } from '#database/DatabaseManager';
import { CommandHandler } from '#handlers/CommandHandler';
import { EventLoader } from '#handlers/EventLoader';
import { MusicManager } from '#managers/MusicManager';
import { logger } from '#utils/logger';

let shardInfo = null;
try {
	shardInfo = getInfo();
} catch (error) {
	shardInfo = null;
	console.error(`Error while getting shard info: ${error}`);
}

export class Riya extends Client {
	constructor() {
		const clientOptions = {
			intents: [
				GatewayIntentBits.Guilds,
				GatewayIntentBits.GuildMembers,
				GatewayIntentBits.GuildMessages,
				GatewayIntentBits.GuildVoiceStates,
				GatewayIntentBits.GuildMessageReactions,
				GatewayIntentBits.MessageContent,
			],
			partials: [
				Partials.Channel,
				Partials.GuildMember,
				Partials.Message,
				Partials.User,
			],
			makeCache: Options.cacheWithLimits({
				MessageManager: 100,
				PresenceManager: 0,
				UserManager: 100,
			}),
			failIfNotExists: false,
			allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
		};

		if (shardInfo) {
			clientOptions.shards = shardInfo.SHARD_LIST;
			clientOptions.shardCount = shardInfo.TOTAL_SHARDS;
		}

		super(clientOptions);

		this.cluster = shardInfo ? new ClusterClient(this) : null;
		this.commands = new Collection();
		this.logger = logger;
		this.config = config;
		this.db = db;
		this.music = new MusicManager(this);
		this.lavalink = this.music.lavalink;

		this.commandHandler = new CommandHandler(this);
		this.eventHandler = new EventLoader(this);

		this.startTime = Date.now();
		this.rest = new REST({ version: '10' }).setToken(config.token);
	}

	async init() {
		this.logger.info('RIYA', `🎶 Initializing bot...`);
		try {
			await this.eventHandler.loadAllEvents();
			await this.commandHandler.loadCommands();
			await this.login(config.token);

			this.logger.success(
				'RIYA',
				`🎶 Bot has successfully initialized. 🌸`,
			);
			this.logger.info('RIYA', '🎶 Developed by ARIAN');
		} catch (error) {
			this.logger.error(
				'RIYA',
				'🎶 Failed to initialize bot cluster:',
				error,
			);
			throw error;
		}
	}

	async cleanup() {
		this.logger.warn('RIYA', `🎶 Starting cleanup for bot...`);
		try {
			await this.db.closeAll();
			this.destroy();
			this.logger.success(
				'RIYA',
				'🎶 Cleanup completed successfully. 🌸',
			);
		} catch (error) {
			this.logger.error(
				'RIYA',
				'🎶 An error occurred during cleanup:',
				error,
			);
		}
	}

	get uptime() {
		return Date.now() - this.startTime;
	}
}
