#!/usr/bin/env bash
# RIYA ᝰ.ᐟ — optional: host your OWN Lavalink music server (needs Java 17+).
# Usage:  npm run lavalink        (leave it running in a second terminal)
# Then in .env use:  LAVALINK_HOST=localhost  LAVALINK_PORT=2333  LAVALINK_PASSWORD=youshallnotpass  LAVALINK_SECURE=false
set -e
mkdir -p lavalink && cd lavalink

if ! command -v java >/dev/null 2>&1; then
  echo "Java is not installed. In Codespaces run:  sudo apt-get update && sudo apt-get install -y openjdk-17-jre-headless"
  exit 1
fi

if [ ! -f Lavalink.jar ]; then
  echo "Downloading latest Lavalink..."
  curl -fL -o Lavalink.jar https://github.com/lavalink-devs/Lavalink/releases/latest/download/Lavalink.jar
fi

if [ ! -f application.yml ]; then
  echo "Looking up the latest YouTube plugin version..."
  YT_VER=$(curl -fsSL https://api.github.com/repos/lavalink-devs/youtube-source/releases/latest | grep '"tag_name"' | head -1 | sed -E 's/.*"tag_name": *"v?([^"]+)".*/\1/')
  if [ -z "$YT_VER" ]; then echo "Could not detect plugin version (GitHub rate limit?). Try again in a minute."; exit 1; fi
  echo "YouTube plugin: $YT_VER"
  cat > application.yml <<YML
server:
  port: 2333
  address: 0.0.0.0
lavalink:
  plugins:
    - dependency: "dev.lavalink.youtube:youtube-plugin:${YT_VER}"
      snapshot: false
  server:
    password: "youshallnotpass"
    sources:
      youtube: false
      soundcloud: true
      bandcamp: true
      twitch: true
      vimeo: true
      http: true
      local: false
plugins:
  youtube:
    enabled: true
    allowSearch: true
    allowDirectVideoIds: true
    allowDirectPlaylistIds: true
    clients:
      - MUSIC
      - WEBEMBEDDED
      - ANDROID_VR
      - TV
YML
fi

echo "Starting Lavalink on port 2333 ..."
exec java -Xmx512m -jar Lavalink.jar
