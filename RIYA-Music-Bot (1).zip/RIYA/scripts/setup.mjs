// RIYA ᝰ.ᐟ — interactive .env creator.   Usage:  npm run setup
import fs from 'node:fs';
import readline from 'node:readline';
import { stdin as input, stdout as output } from 'node:process';

// Line queue: works for typing, pasting several lines at once, and piped input.
const rl = readline.createInterface({ input, terminal: false });
const queue = [];
const waiters = [];
let closed = false;
rl.on('line', line => (waiters.length ? waiters.shift()(line) : queue.push(line)));
rl.on('close', () => {
	closed = true;
	while (waiters.length) waiters.shift()('');
});
const ask = async (q, fallback = '') => {
	output.write(q);
	const line = queue.length ? queue.shift() : closed ? '' : await new Promise(res => waiters.push(res));
	return line.trim() || fallback;
};

console.log('\n  RIYA ᝰ.ᐟ — setup  (Developed by ARIAN)\n');
if (fs.existsSync('.env')) {
	const again = await ask('  .env already exists. Overwrite it? (y/N): ', 'n');
	if (!/^y/i.test(again)) {
		console.log('\n  Kept your existing .env. Start the bot with:  npm start\n');
		rl.close();
		process.exit(0);
	}
}

const token = await ask('  1/3  Bot token                : ');
const clientId = await ask('  2/3  Bot application (client) ID: ');
const owner = await ask('  3/3  Your Discord user ID (owner): ');
const prefix = await ask('       Prefix [.]               : ', '.');
rl.close();

if (!token || !clientId || !owner) {
	console.log('\n  Token, client ID and owner ID are required — nothing written. Run again.\n');
	process.exit(1);
}

let env = fs.readFileSync('.env.example', 'utf8');
const set = (key, value) => {
	env = env.replace(new RegExp(`^${key}=.*$`, 'm'), () => `${key}=${value}`);
};
set('DISCORD_TOKEN', token);
set('CLIENT_ID', clientId);
set('OWNER_IDS', owner);
set('PREFIX', prefix);
set('STATUS_TEXT', `${prefix}help | RIYA ᝰ.ᐟ`);
fs.writeFileSync('.env', env);

console.log('\n  ✔ .env created.  Start the bot with:  npm start\n');
